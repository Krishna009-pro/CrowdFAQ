/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { GoogleGenAI, Type } from "@google/genai";
import { db } from "../db/store";
import { Question } from "../types";

// Lazy initialize Gemini client to prevent startup failure if key is missing
let aiClient: GoogleGenAI | null = null;

function getAiClient(): GoogleGenAI | null {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key) {
      console.warn("⚠️ GEMINI_API_KEY environment variable is not defined. AI features will fallback to smart heuristics.");
      return null;
    }
    aiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
  }
  return aiClient;
}

/**
 * 1. AI-Powered Duplicate Detection
 * Checks if the newly drafted question is a duplicate of any existing question in our database.
 */
export interface DuplicateCheckResult {
  isDuplicate: boolean;
  matchedQuestionId?: string;
  matchedQuestionTitle?: string;
  explanation?: string;
}

export async function detectDuplicates(title: string, description: string): Promise<DuplicateCheckResult> {
  const ai = getAiClient();
  const existingQuestions = db.getQuestions();

  if (existingQuestions.length === 0) {
    return { isDuplicate: false };
  }

  // Prepared short context of questions to search
  const candidates = existingQuestions.map(q => ({
    id: q.id,
    title: q.title,
    description: q.description,
  }));

  if (!ai) {
    // Basic local keyword / title heuristic fallback if offline
    const lowerTitle = title.toLowerCase();
    const match = existingQuestions.find(q => q.title.toLowerCase().includes(lowerTitle) || lowerTitle.includes(q.title.toLowerCase()));
    if (match) {
      return {
        isDuplicate: true,
        matchedQuestionId: match.id,
        matchedQuestionTitle: match.title,
        explanation: `Potential duplicate of matching title containing: "${match.title}".`,
      };
    }
    return { isDuplicate: false };
  }

  try {
    const prompt = `Analyze this draft question and determine if it is a duplicate of any question in the following catalog of existing questions.
We define a duplicate as a question that asks the exact same thing or shares >80% semantic meaning, even if phrased differently.

Draft Title: "${title}"
Draft Description: "${description}"

Candidates:
${JSON.stringify(candidates, null, 2)}

Identify if there is a highly matching question. If yes, specify its ID and title, and explain why. If no candidate is a duplicate, return isDuplicate = false.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            isDuplicate: { type: Type.BOOLEAN },
            matchedQuestionId: { type: Type.STRING, description: "The ID of the matched question if isDuplicate is true" },
            matchedQuestionTitle: { type: Type.STRING, description: "The title of the matched question if isDuplicate is true" },
            explanation: { type: Type.STRING, description: "A neat 1-sentence warning for the user explaining the duplication connection" },
          },
          required: ["isDuplicate"],
        },
      },
    });

    const parsed: DuplicateCheckResult = JSON.parse(response.text || "{}");
    return parsed;
  } catch (error) {
    console.error("Error detecting duplicates via Gemini API:", error);
    return { isDuplicate: false };
  }
}

/**
 * 2. AI Answer Summarization
 * Summarizes multiple answers for a popular question into a neat 3-sentence summary at the top.
 */
export async function summarizeThreadAnswers(questionId: string): Promise<string> {
  const ai = getAiClient();
  const q = db.getQuestionById(questionId);
  const answers = db.getAnswers(questionId);

  if (!q || answers.length === 0) {
    return "";
  }

  const answersContent = answers.map((ans, i) => `Answer #${i+1} by ${ans.authorName} (${ans.authorRole}):\n${ans.body}`).join("\n\n");

  if (!ai) {
    return "Summarization offline. Please check back when AI services are enabled.";
  }

  try {
    const prompt = `You are an expert academic moderator. Summarize the following community answers for the question "${q.title}".
Provide a concise, 2-line summary that combines verified institutional knowledge (prefer answers with Admin or Expert role) and peer guidance.
Make it directly useful so students can get their core answer in 5 seconds.

Answers:
${answersContent}`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: "Write a neat 2-line answer summary of the thread. Keep it dense, accurate, and completely action-oriented.",
      }
    });

    return response.text?.trim() || "No summary available.";
  } catch (error) {
    console.error("Error summarizing thread answers via Gemini:", error);
    return "Could not generate AI summary at this time.";
  }
}

/**
 * 3. AI Chat Assistant (RAG Pipeline)
 * Takes a user query, searches the FAQ database, prepares context, and writes code or answers via Gemini.
 */
export async function queryRAGChatbot(userMessage: string, sessionId: string): Promise<string> {
  const ai = getAiClient();
  const allQuestions = db.getQuestions();
  
  // RAG - find matching context by searching FAQ database elements
  // Let's gather the top questions and their respective answers
  const faqContext = allQuestions.slice(0, 7).map(q => {
    const qAnswers = db.getAnswers(q.id);
    const answersText = qAnswers.map(a => `- [${a.authorRole}] ${a.authorName}: ${a.body}`).join("\n");
    return `Question: ${q.title}\nDescription: ${q.description}\nAnswers:\n${answersText || "No answers yet."}`;
  }).join("\n\n---\n\n");

  const chatHistory = db.getChatHistory(sessionId);
  db.appendChatHistory(sessionId, 'user', userMessage);

  if (!ai) {
    return "Hello! I am currently running in Offline mode since the AI services API key isn't active. Feel free to browse our centralized Placement and Scholarship information in the dashboard!";
  }

  try {
    // Construct local chat session
    const contents: any[] = [
      {
        role: "user",
        parts: [{
          text: `You are CrowdBot, a polite and helpful academic and placements AI Chat Assistant of the CrowdFAQ community portal.
Use the verified FAQ Database Context provided below to answer user inquiries accurately and in a friendly manner.
If the answer is found in the database, prioritize verified Expert or Admin answers. Mention that it comes from verified community records.
If the enquiry is not answered in the context, guide the user to ask a new question on the platform so community experts can contribute!

FAQ Database Context:
${faqContext}

User Query: "${userMessage}"`
        }]
      }
    ];

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents,
      config: {
        systemInstruction: "You are the friendly academic assist bot CrowdBot. Keep responses concise, supportive, and formatted in markdown. Limit text to 3-4 bullet points maximum.",
      }
    });

    const botReply = response.text?.trim() || "I apologize, I could not synthesize a response. Let me know if you would like me to lookup placements or admissions again.";
    db.appendChatHistory(sessionId, 'assistant', botReply);
    return botReply;
  } catch (error) {
    console.error("Error in RAG chatbot loop via Gemini:", error);
    return "I ran into a server error processing that query. Please make sure your Gemini keys are fully configured in Secrets.";
  }
}

/**
 * 4. Auto-Tags & Category Prompts
 * Automatically suggests the best category and 3-5 tags for a question being written.
 */
export interface TagHeuristicResult {
  category: string;
  tags: string[];
}

export async function suggestTagsAndCategory(title: string, description: string): Promise<TagHeuristicResult> {
  const ai = getAiClient();
  const allowedCategories = ["Admissions", "Placements", "Scholarships", "General", "Academics"];

  if (!ai) {
    // Simple heuristic fallback
    const text = (title + " " + description).toLowerCase();
    let category = "General";
    if (text.includes("placement") || text.includes("ctc") || text.includes("package") || text.includes("interview")) {
      category = "Placements";
    } else if (text.includes("scholarship") || text.includes("internship") || text.includes("stipend")) {
      category = "Scholarships";
    } else if (text.includes("apply") || text.includes("admission") || text.includes("portal") || text.includes("fees")) {
      category = "Admissions";
    }
    return {
      category,
      tags: ["help", category.toLowerCase()]
    };
  }

  try {
    const prompt = `Analyze this draft question and suggest:
1. The single best category from this allowed list only: ${JSON.stringify(allowedCategories)}
2. A list of 3-5 highly relevant concise tags (maximum 15 characters each, lowercase, no spaces or hashtags).

Title: "${title}"
Description: "${description}"`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            category: { type: Type.STRING, description: "Must be exactly one of the allowed categories list" },
            tags: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: "3-5 key lowercase tags (no spaces or hash prefix)"
            }
          },
          required: ["category", "tags"]
        }
      }
    });

    const parsed: TagHeuristicResult = JSON.parse(response.text || "{}");
    // Ensure category is from the valid list
    if (!allowedCategories.includes(parsed.category)) {
      parsed.category = "General";
    }
    return parsed;
  } catch (error) {
    console.error("Error auto-suggesting tags via Gemini:", error);
    return { category: "General", tags: ["faq"] };
  }
}
