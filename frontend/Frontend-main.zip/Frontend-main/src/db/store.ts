/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { User, Question, Answer, Comment, UserRole } from '../types';

// Password safety with crypto
export function hashPassword(password: string): string {
  return crypto.createHash('sha256').update(password).digest('hex');
}

// Database JSON model structure
interface DatabaseSchema {
  users: { [id: string]: User & { passwordHash: string } };
  questions: { [id: string]: Question };
  answers: { [id: string]: Answer };
  chatSessions: { [sessionId: string]: { id: string; role: 'user' | 'assistant'; text: string; createdAt: string }[] };
  notifications: { [userId: string]: { id: string; text: string; read: boolean; createdAt: string }[] };
}

const DB_PATH = path.join(process.cwd(), 'database-store.json');

// Initial seed data
const initialUsers: (User & { passwordHash: string })[] = [
  {
    id: 'user_admin',
    email: 'admin@crowdfaq.edu',
    name: 'Prof. Sarah Jenkins',
    role: 'Admin',
    points: 120,
    badges: ['First Responder', 'Expert Helper', 'Policy Maker'],
    biography: 'Director of Academic Affairs. Here to provide verified institutional instructions.',
    passwordHash: hashPassword('admin123'),
    createdAt: new Date(Date.now() - 30 * 24 * 3600 * 1000).toISOString(),
  },
  {
    id: 'user_expert',
    email: 'expert@crowdfaq.edu',
    name: 'Aarav Mehta',
    role: 'Expert',
    points: 85,
    badges: ['Top Contributor', 'First Responder'],
    biography: 'Senior Student Lead & placement volunteer. Happy to answer placements and admissions questions.',
    passwordHash: hashPassword('expert123'),
    createdAt: new Date(Date.now() - 20 * 24 * 3600 * 1000).toISOString(),
  },
  {
    id: 'user_student',
    email: 'student@crowdfaq.edu',
    name: 'Neha Sharma',
    role: 'Student/Employee',
    points: 15,
    badges: ['Beginner'],
    biography: 'Pre-final year Computer Science student. Interested in tech placements and internships.',
    passwordHash: hashPassword('student123'),
    createdAt: new Date(Date.now() - 10 * 24 * 3600 * 1000).toISOString(),
  },
];

const initialQuestions: Question[] = [
  {
    id: 'q_1',
    title: 'How do I apply for the IIT Ropar internship program?',
    description: 'I am a pre-final year CS student looking for the application portal, timelines, and coordinator details for the IIT Ropar internship initiative.',
    category: 'Scholarships',
    tags: ['IITRopar', 'Internship', 'Admissions'],
    authorId: 'user_student',
    authorName: 'Neha Sharma',
    authorRole: 'Student/Employee',
    votesCount: 8,
    votes: { 'user_expert': 'up', 'user_admin': 'up' },
    viewsCount: 145,
    answersCount: 1,
    isDuplicate: false,
    aiSummary: 'The main portal opens from Feb to April. Send your resume directly to the head coordinator and apply via the official IIT Ropar Academic Portal.',
    createdAt: new Date(Date.now() - 5 * 24 * 3600 * 1000).toISOString(),
  },
  {
    id: 'q_2',
    title: 'Where is the central placement office located and what are the contact timings?',
    description: 'I need to physical submit my verified resume sheets to the placement desk. Which building is it in?',
    category: 'Placements',
    tags: ['Placements', 'Office', 'Contact'],
    authorId: 'user_student',
    authorName: 'Neha Sharma',
    authorRole: 'Student/Employee',
    votesCount: 4,
    votes: { 'user_student': 'up' },
    viewsCount: 92,
    answersCount: 1,
    isDuplicate: false,
    createdAt: new Date(Date.now() - 3 * 24 * 3600 * 1000).toISOString(),
  }
];

const initialAnswers: Answer[] = [
  {
    id: 'a_1',
    questionId: 'q_1',
    body: 'The IIT Ropar internship application is handled online. You must visit the academic portal at `http://www.iitrpr.ac.in/academic-internship`. Fill out the Form-A, get it signed by our department head, and upload college transcript sheets. Applications generally close in late April.',
    authorId: 'user_expert',
    authorName: 'Aarav Mehta',
    authorRole: 'Expert',
    votesCount: 5,
    votes: { 'user_admin': 'up', 'user_student': 'up' },
    isBest: true,
    isVerified: true,
    comments: [
      {
        id: 'c_1',
        body: 'Thank you Aarav! This is highly helpful, completed my application yesterday.',
        authorId: 'user_student',
        authorName: 'Neha Sharma',
        authorRole: 'Student/Employee',
        createdAt: new Date(Date.now() - 4 * 24 * 3600 * 1000).toISOString(),
      }
    ],
    createdAt: new Date(Date.now() - 4 * 24 * 3600 * 1000).toISOString(),
  },
  {
    id: 'a_2',
    questionId: 'q_2',
    body: 'The Central Placement Office is located on the **3rd floor of the Administration Block** (Room 304). The helpdesk is active from Monday to Friday, between 10:00 AM and 5:00 PM. Best to go before 1 PM to avoid student lines!',
    authorId: 'user_admin',
    authorName: 'Prof. Sarah Jenkins',
    authorRole: 'Admin',
    votesCount: 10,
    votes: { 'user_expert': 'up', 'user_student': 'up' },
    isBest: false,
    isVerified: true, // gets the green shield badge due to Admin role
    comments: [],
    createdAt: new Date(Date.now() - 2 * 24 * 3600 * 1000).toISOString(),
  }
];

class DatabaseConnection {
  private data: DatabaseSchema = {
    users: {},
    questions: {},
    answers: {},
    chatSessions: {},
    notifications: {},
  };

  constructor() {
    this.load();
  }

  private load() {
    try {
      if (fs.existsSync(DB_PATH)) {
        const raw = fs.readFileSync(DB_PATH, 'utf-8');
        this.data = JSON.parse(raw);
      } else {
        // Seed database
        initialUsers.forEach(u => {
          this.data.users[u.id] = u;
        });
        initialQuestions.forEach(q => {
          this.data.questions[q.id] = q;
        });
        initialAnswers.forEach(a => {
          this.data.answers[a.id] = a;
        });
        this.save();
      }
    } catch (e) {
      console.error('Error loading database file:', e);
    }
  }

  public save() {
    try {
      fs.writeFileSync(DB_PATH, JSON.stringify(this.data, null, 2), 'utf-8');
    } catch (e) {
      console.error('Error saving database file:', e);
    }
  }

  // User Actions
  public getUsers() { return Object.values(this.data.users); }
  public getUserById(id: string) { return this.data.users[id]; }
  public getUserByEmail(email: string) {
    return Object.values(this.data.users).find(u => u.email.toLowerCase() === email.toLowerCase());
  }

  public createUser(email: string, name: string, role: UserRole, biography: string, passwordHash: string): User {
    const id = 'user_' + Math.random().toString(36).substr(2, 9);
    const newUser: User & { passwordHash: string } = {
      id,
      email,
      name,
      role,
      points: 0,
      badges: ['Beginner'],
      biography: biography || 'Community member of CrowdFAQ.',
      passwordHash,
      createdAt: new Date().toISOString(),
    };
    this.data.users[id] = newUser;
    this.save();
    return newUser;
  }

  public addPoints(userId: string, amount: number) {
    const user = this.data.users[userId];
    if (user) {
      const oldPoints = user.points;
      user.points += amount;
      
      // Automatic gamified badges logic (Reputation System)
      // Check thresholds: points > 50 -> "Expert Helper"
      // Verify answers count or receive upvote count can unlocked:
      // If points just crossed 50
      if (oldPoints < 50 && user.points >= 50 && !user.badges.includes('Expert Helper')) {
        user.badges.push('Expert Helper');
        this.addNotification(userId, 'Congratulations! You earned the "Expert Helper" badge by reaching 50 reputation points!');
      }
      // If points just crossed 100
      if (oldPoints < 100 && user.points >= 100 && !user.badges.includes('Top Contributor')) {
        user.badges.push('Top Contributor');
        this.addNotification(userId, 'Wow! You have been awarded the "Top Contributor" badge for crossing 100 reputation points!');
      }
      this.save();
    }
  }

  public updateUserProfile(userId: string, name: string, biography: string, role?: UserRole): User | null {
    const user = this.data.users[userId];
    if (user) {
      user.name = name;
      user.biography = biography;
      if (role && (user.id === 'user_admin' || user.id === 'user_expert' || ['Student/Employee', 'Expert', 'Admin'].includes(role))) {
        user.role = role;
      }
      this.save();
      return user;
    }
    return null;
  }

  // Questions Actions
  public getQuestions() { return Object.values(this.data.questions).sort((a,b) => b.createdAt.localeCompare(a.createdAt)); }
  public getQuestionById(id: string) { return this.data.questions[id]; }

  public createQuestion(title: string, description: string, category: string, tags: string[], authorId: string, authorName: string, authorRole: UserRole): Question {
    const id = 'q_' + Math.random().toString(36).substr(2, 9);
    const newQuestion: Question = {
      id,
      title,
      description,
      category,
      tags: tags.map(t => t.trim().replace(/^#/, '')).filter(Boolean),
      authorId,
      authorName,
      authorRole,
      votesCount: 0,
      votes: {},
      viewsCount: 0,
      answersCount: 0,
      isDuplicate: false,
      createdAt: new Date().toISOString(),
    };
    this.data.questions[id] = newQuestion;
    
    // Reward points for asking (+5 points as defined in OCR page 8)
    this.addPoints(authorId, 5);

    this.save();
    return newQuestion;
  }

  public voteQuestion(questionId: string, userId: string, dir: 'up' | 'down'): Question | null {
    const q = this.data.questions[questionId];
    if (!q) return null;

    if (!q.votes) q.votes = {};

    const existing = q.votes[userId];
    if (existing === dir) {
      // Remove vote
      delete q.votes[userId];
    } else {
      q.votes[userId] = dir;
    }

    // Recalculate vote count
    q.votesCount = Object.values(q.votes).reduce((acc, v) => acc + (v === 'up' ? 1 : -1), 0);
    this.save();
    return q;
  }

  public incrementQuestionViews(questionId: string) {
    const q = this.data.questions[questionId];
    if (q) {
      q.viewsCount += 1;
      this.save();
    }
  }

  public updateQuestionAiSummary(questionId: string, summary: string) {
    const q = this.data.questions[questionId];
    if (q) {
      q.aiSummary = summary;
      this.save();
    }
  }

  public flagAsDuplicate(questionId: string, originalId: string, originalTitle: string) {
    const q = this.data.questions[questionId];
    if (q) {
      q.isDuplicate = true;
      q.duplicateOfId = originalId;
      q.duplicateOfTitle = originalTitle;
      this.save();
    }
  }

  // Answer Actions
  public getAnswers(questionId: string) {
    return Object.values(this.data.answers)
      .filter(a => a.questionId === questionId)
      .sort((a, b) => {
        // Verified first, then best, then votes, then date
        if (a.isVerified !== b.isVerified) return a.isVerified ? -1 : 1;
        if (a.isBest !== b.isBest) return a.isBest ? -1 : 1;
        return b.votesCount - a.votesCount;
      });
  }

  public getAnswerById(id: string) { return this.data.answers[id]; }

  public createAnswer(questionId: string, body: string, authorId: string, authorName: string, authorRole: UserRole): Answer | null {
    const q = this.data.questions[questionId];
    if (!q) return null;

    const id = 'a_' + Math.random().toString(36).substr(2, 9);
    const newAnswer: Answer = {
      id,
      questionId,
      body,
      authorId,
      authorName,
      authorRole,
      votesCount: 0,
      votes: {},
      isBest: false,
      isVerified: false,
      comments: [],
      createdAt: new Date().toISOString(),
    };
    this.data.answers[id] = newAnswer;

    // Increment question answer count
    q.answersCount = (q.answersCount || 0) + 1;

    // Reward points for answering (+10 points as defined in OCR page 9)
    this.addPoints(authorId, 10);

    // Notify question owner
    if (q.authorId !== authorId) {
      this.addNotification(q.authorId, `Your question "${q.title.substring(0, 30)}..." received a new answer from ${authorName}!`);
    }

    this.save();
    return newAnswer;
  }

  public voteAnswer(answerId: string, userId: string, dir: 'up' | 'down'): Answer | null {
    const a = this.data.answers[answerId];
    if (!a) return null;

    if (!a.votes) a.votes = {};

    const existing = a.votes[userId];
    const oldScore = a.votesCount;

    if (existing === dir) {
      delete a.votes[userId];
    } else {
      a.votes[userId] = dir;
    }

    a.votesCount = Object.values(a.votes).reduce((acc, v) => acc + (v === 'up' ? 1 : -1), 0);
    const newScore = a.votesCount;

    // Receive upvote award: +2 points to author (defined in OCR page 9)
    if (newScore > oldScore && a.authorId) {
      this.addPoints(a.authorId, 2);
    }

    this.save();
    return a;
  }

  public acceptAnswerAsBest(answerId: string): Answer | null {
    const a = this.data.answers[answerId];
    if (!a) return null;

    // Find other answers belonging to same question and mark isBest false
    Object.values(this.data.answers).forEach(ans => {
      if (ans.questionId === a.questionId) {
        ans.isBest = false;
      }
    });

    a.isBest = true;

    // Award +20 points for Best Answer (OCR page 9)
    this.addPoints(a.authorId, 20);
    
    // Notification
    this.addNotification(a.authorId, 'Congratulations! Your response was accepted as the Best Answer (+20 reputation!).');

    this.save();
    return a;
  }

  public verifyAnswer(answerId: string, verifierId: string, verifierName: string): Answer | null {
    const a = this.data.answers[answerId];
    const verifier = this.data.users[verifierId];
    if (!a || !verifier) return null;

    // Verify role can verify (Admin or Expert)
    if (verifier.role !== 'Admin' && verifier.role !== 'Expert') return null;

    a.isVerified = true;
    
    // Award +10 points to author for official verification
    this.addPoints(a.authorId, 10);

    this.addNotification(a.authorId, `Excellent! Your answer was officially verified by ${verifierName} (+10 points!).`);

    this.save();
    return a;
  }

  // Comment Actions
  public addComment(answerId: string, body: string, authorId: string, authorName: string, authorRole: UserRole): Comment | null {
    const a = this.data.answers[answerId];
    if (!a) return null;

    const newComment: Comment = {
      id: 'c_' + Math.random().toString(36).substr(2, 9),
      body,
      authorId,
      authorName,
      authorRole,
      createdAt: new Date().toISOString(),
    };
    if (!a.comments) a.comments = [];
    a.comments.push(newComment);

    this.save();
    return newComment;
  }

  // Notifications
  public addNotification(userId: string, text: string) {
    if (!this.data.notifications) this.data.notifications = {};
    if (!this.data.notifications[userId]) this.data.notifications[userId] = [];
    
    this.data.notifications[userId].push({
      id: 'n_' + Math.random().toString(36).substr(2, 9),
      text,
      read: false,
      createdAt: new Date().toISOString(),
    });
    this.save();
  }

  public getNotifications(userId: string) {
    if (!this.data.notifications || !this.data.notifications[userId]) return [];
    return this.data.notifications[userId].sort((a,b) => b.createdAt.localeCompare(a.createdAt));
  }

  public markNotificationsRead(userId: string) {
    if (this.data.notifications && this.data.notifications[userId]) {
      this.data.notifications[userId].forEach(n => n.read = true);
      this.save();
    }
  }

  // Chat/RAG System Memory
  public getChatHistory(sessionId: string) {
    if (!this.data.chatSessions) this.data.chatSessions = {};
    return this.data.chatSessions[sessionId] || [];
  }

  public appendChatHistory(sessionId: string, role: 'user' | 'assistant', text: string) {
    if (!this.data.chatSessions) this.data.chatSessions = {};
    if (!this.data.chatSessions[sessionId]) this.data.chatSessions[sessionId] = [];

    this.data.chatSessions[sessionId].push({
      id: 'm_' + Math.random().toString(36).substr(2, 9),
      role,
      text,
      createdAt: new Date().toISOString(),
    });
    this.save();
  }
}

export const db = new DatabaseConnection();
