/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

// Format relative date (e.g., "5 hours ago")
export function formatRelativeDate(dateString: string): string {
  try {
    const past = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - past.getTime();

    const diffMins = Math.floor(diffMs / 60000);
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;

    const diffHours = Math.floor(diffMins / 60);
    if (diffHours < 24) return `${diffHours}h ago`;

    const diffDays = Math.floor(diffHours / 24);
    if (diffDays === 1) return 'Yesterday';
    if (diffDays < 30) return `${diffDays}d ago`;

    return past.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
  } catch {
    return 'Recently';
  }
}

// Generate initials from a name (e.g., "Sarah Jenkins" -> "SJ")
export function getInitials(name: string): string {
  if (!name) return '??';
  const parts = name.trim().split(/\s+/);
  if (parts.length === 1) return parts[0].substring(0, 2).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}

// Map roles to gorgeous badges that user can wear/see in UI
export const ROLE_STYLES = {
  'Admin': {
    label: 'Admin (Faculty/Management)',
    badgeClass: 'bg-red-50 text-red-700 dark:bg-red-950/40 dark:text-red-400 border border-red-200/50 dark:border-red-900/40',
    iconColor: 'text-red-600 dark:text-red-400',
    dotClass: 'bg-red-500',
    colorHex: '#EF4444',
  },
  'Expert': {
    label: 'Expert (Senior Student Lead)',
    badgeClass: 'bg-blue-50 text-blue-700 dark:bg-blue-950/40 dark:text-blue-400 border border-blue-200/50 dark:border-blue-900/40',
    iconColor: 'text-blue-600 dark:text-blue-400',
    dotClass: 'bg-blue-500',
    colorHex: '#3B82F6',
  },
  'Student/Employee': {
    label: 'Student/Employee',
    badgeClass: 'bg-gray-50 text-gray-700 dark:bg-gray-800 dark:text-gray-300 border border-gray-200 dark:border-gray-750',
    iconColor: 'text-gray-500 dark:text-gray-400',
    dotClass: 'bg-gray-400',
    colorHex: '#9CA3AF',
  }
};

// Map badges to specific icons and achievement notes
export interface BadgeInfo {
  name: string;
  emoji: string;
  color: string;
  description: string;
  requirement: string;
}

export const BADGE_REGISTRY: { [key: string]: BadgeInfo } = {
  'Beginner': {
    name: 'Beginner',
    emoji: '🌱',
    color: 'from-emerald-400 to-teal-500',
    description: 'Welcome to CrowdFAQ community! Awarded upon successfully registering and joining.',
    requirement: 'Granted automatically on account creation',
  },
  'Expert Helper': {
    name: 'Expert Helper',
    emoji: '🤝',
    color: 'from-blue-400 to-indigo-500',
    description: 'Highly resourceful helper with premium active advice reputation points.',
    requirement: 'Earn 50+ overall reputation points on answers',
  },
  'Top Contributor': {
    name: 'Top Contributor',
    emoji: '🏆',
    color: 'from-amber-400 to-orange-500',
    description: 'Exceptional pillar of community wisdom who consistently answers the most critical FAQs.',
    requirement: 'Earn 100+ overall reputation points',
  },
  'First Responder': {
    name: 'First Responder',
    emoji: '⚡',
    color: 'from-rose-400 to-pink-500',
    description: 'Unbelievably quick, answering fresh outstanding questions right within hours!',
    requirement: 'Awarded dynamically for being the first answerer on active folders',
  },
  'Policy Maker': {
    name: 'Policy Maker',
    emoji: '⚖️',
    color: 'from-purple-400 to-violet-500',
    description: 'Distinguished university board, faculty lead, or administrative expert coordinator.',
    requirement: 'Granted exclusively to institutional Admin roles',
  }
};

// Generates a deterministic gradient based on username
export function getAvatarGradient(name: string): string {
  const hash = name.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  const gradients = [
    'from-pink-500 to-rose-500',
    'from-indigo-500 to-blue-500',
    'from-violet-500 to-purple-500',
    'from-emerald-500 to-green-500',
    'from-amber-500 to-orange-500',
    'from-cyan-500 to-blue-500',
  ];
  return gradients[hash % gradients.length];
}
