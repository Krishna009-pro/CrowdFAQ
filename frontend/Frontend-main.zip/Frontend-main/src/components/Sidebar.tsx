/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useAuth } from '../context/AuthContext';
import { LayoutDashboard, Trophy, User, PlusCircle, HelpCircle } from 'lucide-react';
import { motion } from 'motion/react';

interface SidebarProps {
  currentPage: string;
  onNavigate: (page: string, params?: any) => void;
  onOpenAskModal: () => void;
}

export default function Sidebar({ currentPage, onNavigate, onOpenAskModal }: SidebarProps) {
  const { user } = useAuth();

  const navItems = [
    { id: 'feed', label: 'Q&A Dashboard', icon: LayoutDashboard },
    { id: 'leaderboard', label: 'Leaderboard', icon: Trophy },
  ];

  if (user) {
    navItems.push({ id: 'profile', label: 'My Profile', icon: User });
  }

  return (
    <aside id="app-sidebar" className="sticky top-16 left-0 hidden h-[calc(100vh-4rem)] w-64 flex-none border-r border-slate-200 bg-white py-6 pr-4 pl-6 md:flex md:flex-col justify-between dark:border-slate-800 dark:bg-slate-950">
      <div className="flex flex-col gap-6">
        
        {/* Nav list */}
        <nav className="flex flex-col gap-1.5 list-none select-none">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentPage === item.id;
            return (
              <li key={item.id}>
                <button
                  onClick={() => onNavigate(item.id)}
                  className={`group flex w-full items-center gap-3 rounded-md px-4 py-3 text-sm font-semibold transition-all cursor-pointer ${
                    isActive
                      ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/30 dark:text-blue-400'
                      : 'text-slate-605 text-slate-600 hover:bg-slate-50 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-900 dark:hover:text-slate-200'
                  }`}
                >
                  <Icon className={`h-4.5 w-4.5 transition-transform group-hover:scale-105 ${isActive ? 'text-blue-600 dark:text-blue-400' : 'text-slate-400'}`} />
                  <span>{item.label}</span>
                  {isActive && (
                    <motion.div
                      layoutId="sidebar-active-indicator"
                      className="ml-auto h-1.5 w-1.5 rounded-full bg-blue-600 dark:bg-blue-400"
                    />
                  )}
                </button>
              </li>
            );
          })}
        </nav>

        {/* Ask Question Callout trigger */}
        {user && (
          <div className="border-t border-slate-100 pt-4 mt-2 dark:border-slate-850">
            <button
              id="sidebar-btn-ask"
              onClick={onOpenAskModal}
              className="flex w-full items-center justify-center gap-2 rounded-md bg-blue-50 hover:bg-blue-100 text-blue-700 dark:bg-blue-950/30 dark:hover:bg-blue-950/50 dark:text-blue-400 px-4 py-3 text-xs font-bold transition-all cursor-pointer border border-blue-200"
            >
              <PlusCircle className="h-4.5 w-4.5" />
              <span>Ask a Question</span>
            </button>
          </div>
        )}
      </div>

      {/* Micro Metrics / Stats summary widget */}
      <div className="rounded-xl border border-slate-200 p-4 bg-slate-50 dark:border-slate-800 dark:bg-slate-900/40">
        <div className="flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-200">
          <HelpCircle className="h-4 w-4 text-blue-600" />
          <span>Need Assistance?</span>
        </div>
        <p className="mt-1 text-[11px] leading-relaxed text-slate-500 dark:text-slate-400">
          Our bot CrowdBot synthesizes past validated academic and placement advice to help you. Open the bottom chat anytime!
        </p>
      </div>

    </aside>
  );
}
