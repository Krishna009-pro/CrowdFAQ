/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { getInitials, getAvatarGradient, ROLE_STYLES } from '../utils';
import { Trophy, Award, User, Flame, CheckCircle } from 'lucide-react';
import { LeaderboardEntry } from '../types';

export default function LeaderboardPage() {
  const [board, setBoard] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadLeaderboard() {
      try {
        const response = await fetch('/api/v1/leaderboard');
        if (response.ok) {
          const data = await response.json();
          setBoard(data.leaderboard || []);
        }
      } catch (e) {
        console.error(e);
      } finally {
        setLoading(false);
      }
    }

    loadLeaderboard();
  }, []);

  if (loading) {
    return (
      <div className="flex h-96 items-center justify-center font-mono text-xs text-slate-400">
        <span className="size-4 animate-spin rounded-full border-2 border-blue-600 border-t-transparent mr-2" />
        <span>Synthesizing campus reputation leaders...</span>
      </div>
    );
  }

  // podium layout
  const topThree = board.slice(0, 3);
  const remainder = board.slice(3);

  const getMedalColor = (index: number) => {
    if (index === 0) return 'text-amber-500 bg-amber-50 border-amber-200 dark:bg-amber-950/20';
    if (index === 1) return 'text-slate-450 bg-slate-50 border-slate-200';
    return 'text-amber-700 bg-amber-50/50 border-amber-150';
  };

  return (
    <div id="leaderboard-page" className="max-w-4xl mx-auto space-y-6 text-left pb-12 select-none">
      
      {/* 1. Header Banner */}
      <div className="rounded-xl bg-blue-600 p-6 text-white shadow-sm">
        <div className="flex items-center gap-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-white/15">
            <Trophy className="h-6 w-6 text-yellow-300 animate-bounce" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight sm:text-2xl">Campus Hall of Fame</h1>
            <p className="text-xs text-blue-50/90 mt-1 font-sans font-normal">
              Top community helpers earning reputation points by answering unverified FAQs and explaining placements policies.
            </p>
          </div>
        </div>
      </div>

      {/* 2. Top 3 Podium Highlights */}
      {topThree.length > 0 && (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          {topThree.map((user, index) => {
            const roleStyle = ROLE_STYLES[user.role] || ROLE_STYLES['Student/Employee'];
            return (
              <div
                key={user.id}
                className={`relative flex flex-col items-center text-center p-5 rounded-xl border bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900/40 ${
                  index === 0 ? 'ring-2 ring-blue-105 dark:ring-blue-900 border-blue-200' : 'border-slate-200'
                }`}
              >
                {/* Crown / Trophy icon label */}
                <div className={`absolute top-4 left-4 flex h-7 w-7 items-center justify-center rounded-lg border text-xs font-bold leading-none ${getMedalColor(index)}`}>
                  {index + 1}
                </div>

                <div className="mt-4 flex flex-col items-center">
                  <div className={`flex h-14 w-14 items-center justify-center rounded-full bg-gradient-to-tr ${getAvatarGradient(user.name)} text-lg font-bold text-white shadow-inner`}>
                    {getInitials(user.name)}
                  </div>
                  <h3 className="mt-3 text-sm font-bold text-slate-900 dark:text-white truncate max-w-[135px]" title={user.name}>
                    {user.name}
                  </h3>
                  <span className={`mt-1.5 rounded px-2 py-0.5 text-[8px] font-semibold tracking-wider uppercase font-mono ${roleStyle.badgeClass}`}>
                    {user.role}
                  </span>
                </div>

                <div className="mt-4 border-t border-slate-100 w-full pt-3 flex items-center justify-between dark:border-slate-805">
                  <div className="text-left">
                    <span className="text-[10px] text-slate-400 block tracking-wider uppercase font-mono">Reputation</span>
                    <span className="text-sm font-bold text-slate-800 dark:text-slate-100 flex items-center gap-0.5">
                      <Flame className="h-4 w-4 text-orange-500 fill-orange-500" />
                      <span>{user.points} pts</span>
                    </span>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-slate-400 block tracking-wider uppercase font-mono">Badges</span>
                    <span className="text-xs font-bold text-slate-600 dark:text-slate-300">
                      {user.badgesCount} badges
                    </span>
                  </div>
                </div>

              </div>
            );
          })}
        </div>
      )}

      {/* 3. Regular list scoreboard */}
      <div className="rounded-xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900/40 overflow-hidden">
        <div className="p-4 border-b border-slate-100 bg-slate-50 dark:border-slate-800 dark:bg-slate-900/10">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-widest font-mono">Active Contributors Rankings</span>
        </div>

        <div className="divide-y divide-slate-100 dark:divide-slate-805 max-h-96 overflow-y-auto">
          {remainder.length === 0 && topThree.length === 0 ? (
            <div className="py-12 text-center text-xs text-slate-400 font-mono">
              Scoreboard empty. Please ask questions or write responses!
            </div>
          ) : remainder.length === 0 ? (
            <div className="p-4 text-center text-xs text-slate-400">
              Only {topThree.length} community members have climbed the halls of fame. Add more answers to qualify!
            </div>
          ) : (
            remainder.map((member, index) => {
              const roleMeta = ROLE_STYLES[member.role] || ROLE_STYLES['Student/Employee'];
              return (
                <div key={member.id} className="flex items-center justify-between p-4 bg-white dark:bg-transparent hover:bg-slate-50 transition-colors">
                  <div className="flex items-center gap-3">
                    {/* Rank */}
                    <span className="font-mono text-xs font-extrabold text-slate-400 w-5">
                      #{index + 4}
                    </span>

                    {/* Avatar */}
                    <div className={`flex h-8.5 w-8.5 items-center justify-center rounded-lg bg-gradient-to-tr ${getAvatarGradient(member.name)} text-xs font-bold text-white shadow-inner`}>
                      {getInitials(member.name)}
                    </div>

                    {/* Name detail */}
                    <div className="flex flex-col text-left">
                      <span className="text-xs font-bold text-slate-900 dark:text-white leading-tight">{member.name}</span>
                      <span className={`self-start mt-1 text-[8px] rounded px-1.5 leading-none font-mono ${roleMeta.badgeClass}`}>
                        {member.role}
                      </span>
                    </div>
                  </div>

                  {/* Points */}
                  <div className="flex items-center gap-5 text-right">
                    <div>
                      <span className="text-[9px] text-slate-400 block uppercase tracking-wider font-mono">Badges</span>
                      <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">
                        {member.badgesCount}
                      </span>
                    </div>
                    <div>
                      <span className="text-[9px] text-slate-400 block uppercase tracking-wider font-mono">Reputation</span>
                      <span className="text-xs font-bold text-blue-600 font-mono">
                        {member.points} pts
                      </span>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

    </div>
  );
}
