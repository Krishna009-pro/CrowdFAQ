/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../context/AuthContext';
import { getInitials, getAvatarGradient } from '../utils';
import { Search, Bell, Sun, Moon, LogOut, Check, Sparkles, BookOpen } from 'lucide-react';

interface NavbarProps {
  onSearchChange: (search: string) => void;
  searchVal: string;
  onNavigate: (page: string, params?: any) => void;
  onOpenAskModal: () => void;
}

export default function Navbar({ onSearchChange, searchVal, onNavigate, onOpenAskModal }: NavbarProps) {
  const { user, logout, notifications, markNotificationsRead, theme, toggleTheme } = useAuth();
  const [showNotifications, setShowNotifications] = useState(false);

  const unreadCount = notifications.filter(n => !n.read).length;

  const handleNotificationClick = () => {
    setShowNotifications(!showNotifications);
    if (!showNotifications && unreadCount > 0) {
      markNotificationsRead();
    }
  };

  return (
    <header id="app-navbar" className="sticky top-0 z-40 w-full border-b border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-950">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        
        {/* Logo and branding */}
        <div className="flex items-center gap-3 cursor-pointer select-none" onClick={() => onNavigate('feed')}>
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-600 font-bold text-xl text-white shadow-sm">
            C
          </div>
          <div className="flex flex-col">
            <span className="font-heading text-lg font-bold tracking-tight text-slate-900 dark:text-white">
              Crowd<span className="text-blue-600 dark:text-blue-400">FAQ</span>
            </span>
            <span className="text-[10px] font-mono tracking-wider uppercase text-slate-400">Campus Q&A</span>
          </div>
        </div>

        {/* Universal Search Input */}
        <div className="hidden md:flex flex-1 max-w-md mx-8 relative">
          <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
            <Search className="h-4 w-4 text-slate-400" />
          </div>
          <input
            id="nav-search-bar"
            type="text"
            className="block w-full pl-9 pr-3 py-2 border border-slate-300 rounded-full bg-slate-50 text-sm text-slate-800 placeholder-slate-500 focus:outline-none focus:bg-white focus:ring-2 focus:ring-blue-500 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:focus:bg-slate-950"
            placeholder="Search FAQs, categories, placements..."
            value={searchVal}
            onChange={(e) => {
              onSearchChange(e.target.value);
              onNavigate('feed'); // auto redirect to feed when searching
            }}
          />
        </div>

        {/* Right Interactions Toolbar */}
        <div className="flex items-center gap-3">
          
          {/* Quick Ask Callout */}
          {user && (
            <motion.button
              id="btn-quick-ask"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={onOpenAskModal}
              className="hidden sm:flex items-center gap-1.5 rounded-md bg-blue-600 px-4 py-2 text-xs font-medium text-white shadow-sm hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 cursor-pointer"
            >
              <Sparkles className="h-3.5 w-3.5" />
              <span>Ask Question</span>
            </motion.button>
          )}

          {/* Theme Switcher Button */}
          <button
            id="btn-theme-toggle"
            onClick={toggleTheme}
            className="flex h-10 w-10 items-center justify-center rounded-xl border border-slate-200 text-slate-500 hover:bg-slate-50 hover:text-slate-800 dark:border-slate-800 dark:text-slate-400 dark:hover:bg-slate-900 dark:hover:text-slate-200 cursor-pointer"
          >
            {theme === 'light' ? <Moon className="h-4.5 w-4.5" /> : <Sun className="h-4.5 w-4.5" />}
          </button>

          {/* Notifications Panel Bell */}
          {user && (
            <div className="relative">
              <button
                id="btn-notification-bell"
                onClick={handleNotificationClick}
                className="relative flex h-10 w-10 items-center justify-center rounded-xl border border-gray-200 text-gray-500 hover:bg-gray-100 hover:text-gray-800 dark:border-gray-800 dark:text-gray-400 dark:hover:bg-gray-900 dark:hover:text-gray-200 cursor-pointer"
              >
                <Bell className="h-4.5 w-4.5" />
                {unreadCount > 0 && (
                  <span className="absolute top-2.5 right-2.5 flex h-2 w-2">
                    <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-rose-400 opacity-75"></span>
                    <span className="relative inline-flex h-2 w-2 rounded-full bg-rose-500"></span>
                  </span>
                )}
              </button>

              <AnimatePresence>
                {showNotifications && (
                  <>
                    {/* Overlay to close */}
                    <div className="fixed inset-0 z-30" onClick={() => setShowNotifications(false)} />
                    
                    <motion.div
                      initial={{ opacity: 0, y: 15, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 15, scale: 0.95 }}
                      transition={{ duration: 0.15 }}
                      className="absolute right-0 mt-2 z-40 w-80 rounded-2xl border border-gray-200 bg-white p-3 shadow-xl dark:border-gray-800 dark:bg-gray-950"
                    >
                      <div className="flex items-center justify-between border-b border-gray-100 pb-2 mb-2 dark:border-gray-850">
                        <span className="text-xs font-bold text-gray-900 dark:text-white">Active Notifications</span>
                        <button
                          onClick={() => setShowNotifications(false)}
                          className="text-[10px] text-indigo-500 hover:underline cursor-pointer"
                        >
                          Close
                        </button>
                      </div>

                      <div className="max-h-60 overflow-y-auto space-y-2 pr-1 select-none">
                        {notifications.length === 0 ? (
                          <div className="py-6 text-center text-xs text-gray-400 dark:text-gray-550">
                            No notifications to display.
                          </div>
                        ) : (
                          notifications.map((notif) => (
                            <div
                              key={notif.id}
                              className={`rounded-xl p-2.5 text-xs transition-colors ${
                                !notif.read
                                  ? 'bg-indigo-50/50 dark:bg-indigo-950/20 border-l-2 border-indigo-500'
                                  : 'bg-gray-50/50 dark:bg-gray-900/50 border-l border-gray-200 dark:border-gray-800'
                              }`}
                            >
                              <div className="text-gray-700 dark:text-gray-300">
                                {notif.text}
                              </div>
                              <div className="mt-1 text-[10px] text-gray-400 dark:text-gray-500">
                                {new Date(notif.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </motion.div>
                  </>
                )}
              </AnimatePresence>
            </div>
          )}

          {/* User Account Controls */}
          {user ? (
            <div className="flex items-center gap-2 border-l border-gray-100 pl-3 dark:border-gray-850">
              <div
                className="flex items-center gap-2 cursor-pointer"
                onClick={() => onNavigate('profile')}
              >
                <div className={`flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-tr ${getAvatarGradient(user.name)} text-xs font-bold text-white shadow-inner`}>
                  {getInitials(user.name)}
                </div>
                <div className="hidden lg:flex flex-col leading-none text-left select-none">
                  <span className="text-xs font-semibold text-gray-800 dark:text-gray-200">{user.name}</span>
                  <span className="text-[10px] text-gray-400 font-mono mt-0.5">{user.role}</span>
                </div>
              </div>

              <button
                id="btn-nav-logout"
                onClick={logout}
                title="Log Out of System"
                className="flex h-9 w-9 items-center justify-center rounded-xl text-gray-400 hover:bg-rose-50 hover:text-rose-600 dark:hover:bg-rose-950/30 dark:hover:text-rose-400 cursor-pointer"
              >
                <LogOut className="h-4 w-4" />
              </button>
            </div>
          ) : (
            <button
              onClick={() => onNavigate('auth')}
              className="rounded-full bg-gray-900 dark:bg-white text-white dark:text-gray-900 px-4 py-1.5 text-xs font-semibold hover:bg-gray-800 dark:hover:bg-gray-100 cursor-pointer"
            >
              Sign In
            </button>
          )}

        </div>
      </div>
    </header>
  );
}
