/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../context/AuthContext';
import { getInitials, getAvatarGradient, formatRelativeDate, ROLE_STYLES } from '../utils';
import { 
  ArrowLeft, ArrowBigUp, ArrowBigDown, ShieldCheck, Check, 
  MessageCircle, Sparkles, Send, ShieldAlert, Award 
} from 'lucide-react';
import { Question, Answer, Comment } from '../types';

interface QuestionDetailViewProps {
  questionId: string;
  onNavigate: (page: string) => void;
}

export default function QuestionDetailView({ questionId, onNavigate }: QuestionDetailViewProps) {
  const { user, token } = useAuth();
  
  const [question, setQuestion] = useState<Question | null>(null);
  const [answers, setAnswers] = useState<Answer[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Create Answer Form State
  const [answerBody, setAnswerBody] = useState('');
  const [submittingAnswer, setSubmittingAnswer] = useState(false);
  const [ansError, setAnsError] = useState<string | null>(null);

  // Comments Form State: keeps map of answerId -> comments text input
  const [commentBodies, setCommentBodies] = useState<{ [answerId: string]: string }>({});
  const [submittingComment, setSubmittingComment] = useState<{ [answerId: string]: boolean }>({});

  // AI Summarizer States
  const [summarizing, setSummarizing] = useState(false);
  const [showSummaryUi, setShowSummaryUi] = useState(false);

  const fetchThreadData = useCallback(async () => {
    try {
      const qRes = await fetch(`/api/v1/questions/${questionId}`);
      if (qRes.ok) {
        const qData = await qRes.json();
        setQuestion(qData.question);
      }

      const aRes = await fetch(`/api/v1/questions/${questionId}/answers`);
      if (aRes.ok) {
        const aData = await aRes.json();
        setAnswers(aData.answers || []);
      }
    } catch (e) {
      console.error('Error fetching Q&A detail thread:', e);
    } finally {
      setLoading(false);
    }
  }, [questionId]);

  useEffect(() => {
    fetchThreadData();
  }, [fetchThreadData]);

  // AI-powered Thread Answer Summarization Trigger
  const triggerAiSummarize = async () => {
    if (!question) return;
    setSummarizing(true);
    try {
      const response = await fetch(`/api/v1/questions/${question.id}/summarize`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (response.ok) {
        const result = await response.json();
        setQuestion(prev => prev ? { ...prev, aiSummary: result.summary } : null);
        setShowSummaryUi(true);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setSummarizing(false);
    }
  };

  const handlePostAnswer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) {
      alert('Authentication is required to draft custom answers.');
      onNavigate('auth');
      return;
    }

    if (!answerBody.trim()) {
      setAnsError('Please write your answer body context first.');
      return;
    }

    setSubmittingAnswer(true);
    setAnsError(null);

    try {
      const response = await fetch(`/api/v1/questions/${questionId}/answers`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ body: answerBody })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Server rejected answer draft.');
      }

      setAnswers(prev => [...prev, data.answer]);
      setAnswerBody('');
      
      // Update local answers list and views
      if (question) {
        setQuestion(prev => prev ? { ...prev, answersCount: prev.answersCount + 1 } : null);
      }
    } catch (err: any) {
      setAnsError(err.message);
    } finally {
      setSubmittingAnswer(false);
    }
  };

  const handleVoteAnswer = async (answerId: string, dir: 'up' | 'down') => {
    if (!token) {
      alert('Please log in for voting operations.');
      onNavigate('auth');
      return;
    }

    try {
      const response = await fetch(`/api/v1/answers/${answerId}/vote`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ dir })
      });

      if (response.ok) {
        const data = await response.json();
        setAnswers(prev => prev.map(a => a.id === answerId ? data.answer : a));
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleToggleBestAnswer = async (answerId: string) => {
    if (!token) return;
    try {
      const response = await fetch(`/api/v1/answers/${answerId}/best`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (response.ok) {
        const data = await response.json();
        // Reload answers to trigger ranks reposition
        fetchThreadData();
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handleVerifyAnswer = async (answerId: string) => {
    if (!token) return;
    try {
      const response = await fetch(`/api/v1/answers/${answerId}/verify`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      if (response.ok) {
        const data = await response.json();
        setAnswers(prev => prev.map(a => a.id === answerId ? data.answer : a));
      } else {
        const err = await response.json();
        alert(err.error || 'Only Mentor Experts or Administrators can verify answers.');
      }
    } catch (e) {
      console.error(e);
    }
  };

  const handlePostComment = async (answerId: string) => {
    const body = commentBodies[answerId];
    if (!token) {
      alert('Authentication is required to comment.');
      onNavigate('auth');
      return;
    }

    if (!body || !body.trim()) return;

    setSubmittingComment(prev => ({ ...prev, [answerId]: true }));

    try {
      const response = await fetch(`/api/v1/answers/${answerId}/comments`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ body })
      });

      if (response.ok) {
        const data = await response.json();
        setAnswers(prev => prev.map(ans => {
          if (ans.id === answerId) {
            return {
              ...ans,
              comments: [...(ans.comments || []), data.comment]
            };
          }
          return ans;
        }));
        
        // Clear value
        setCommentBodies(prev => ({ ...prev, [answerId]: '' }));
      }
    } catch (e) {
       console.error(e);
    } finally {
      setSubmittingComment(prev => ({ ...prev, [answerId]: false }));
    }
  };

  if (loading) {
    return (
      <div className="flex h-96 items-center justify-center font-mono text-xs text-slate-400">
        <span className="size-4 animate-spin rounded-full border-2 border-blue-600 border-t-transparent mr-2" />
        <span>Syncing community thread detail datasets...</span>
      </div>
    );
  }

  if (!question) {
    return (
      <div className="rounded-xl border border-slate-200 bg-white p-6 text-center shadow dark:border-slate-800 dark:bg-slate-950">
        <h3 className="font-heading text-lg font-bold text-slate-900 dark:text-white">Question not found</h3>
        <p className="mt-2 text-sm text-slate-400">This thread has either been moderated or never existed.</p>
        <button onClick={() => onNavigate('feed')} className="mt-4 text-xs font-bold text-blue-600 hover:underline">
          Go Back Dashboard
        </button>
      </div>
    );
  }

  const isQuestionAuthor = user?.id === question.authorId;
  const canVerifyRole = user?.role === 'Admin' || user?.role === 'Expert';

  return (
    <div id="thread-detail-container" className="space-y-6 text-left max-w-4xl mx-auto pb-12">
      
      {/* 1. Header Toolbar Back Navigation */}
      <div className="flex items-center gap-2">
        <button
          onClick={() => onNavigate('feed')}
          className="flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 text-slate-500 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-905 cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
        </button>
        <span className="text-xs font-bold text-slate-400 font-mono">Back to community feed</span>
      </div>

      {/* 2. Main Question Card block */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900/40 space-y-4">
        
        {/* Author information & category */}
        <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <div className={`flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-tr ${getAvatarGradient(question.authorName)} text-xs font-bold text-white`}>
              {getInitials(question.authorName)}
            </div>
            <div className="flex flex-col text-left leading-tight">
              <span className="text-xs font-bold text-slate-800 dark:text-gray-100">{question.authorName}</span>
              <span className="text-[10px] text-slate-450 font-mono mt-0.5">{question.authorRole} • Posted {formatRelativeDate(question.createdAt)}</span>
            </div>
          </div>
          <span className="rounded bg-blue-50 px-3 py-0.5 text-xs font-semibold text-blue-700 dark:bg-blue-950/40 dark:text-blue-400 border border-blue-105">
            #{question.category}
          </span>
        </div>

        {/* Question Title & Description */}
        <div className="space-y-2">
          <h1 className="text-lg font-bold tracking-tight text-slate-900 dark:text-white sm:text-xl">
            {question.title}
          </h1>
          <p className="text-sm leading-relaxed text-slate-700 dark:text-slate-300 whitespace-pre-line font-sans">
            {question.description}
          </p>
        </div>

        {/* Question tags */}
        <div className="flex flex-wrap gap-1">
          {question.tags.map(t => (
            <span key={t} className="rounded bg-slate-100 px-2.5 py-0.5 text-xs text-slate-500 font-mono border border-slate-200">
              #{t}
            </span>
          ))}
        </div>

        {/* Universal Views & Metrics counts */}
        <div className="flex items-center gap-4 text-xs font-semibold text-slate-450 font-mono">
          <span>{question.viewsCount} overall views</span>
          <span>{question.answersCount} answers published</span>
        </div>

      </div>

      {/* 3. AI-Powered Thread Answers Summarizer Section */}
      {answers.length > 0 && (
        <div className="rounded-xl border border-blue-200 bg-gradient-to-tr from-blue-50/40 via-white to-slate-50/20 p-5 shadow-sm dark:border-blue-900/40 dark:from-blue-950/10 dark:to-slate-950/5 space-y-3">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2">
              <Sparkles className="h-4.5 w-4.5 text-blue-600 animate-pulse" />
              <h3 className="text-sm font-bold text-transparent bg-gradient-to-r from-blue-600 to-slate-700 bg-clip-text dark:from-blue-400 dark:to-slate-350">
                AI Answer Summarizer
              </h3>
            </div>
            
            <button
              onClick={triggerAiSummarize}
              disabled={summarizing}
              className="flex items-center gap-1 rounded-lg bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 text-xs font-semibold text-white px-3.5 py-1.5 shadow-sm cursor-pointer"
            >
              <Sparkles className="h-3 w-3" />
              <span>{summarizing ? 'Synthesizing...' : question.aiSummary ? 'Refresh AI Summary' : 'Generate AI Summary'}</span>
            </button>
          </div>

          {question.aiSummary ? (
            <div className="rounded-lg border border-blue-100 bg-white/70 p-3.5 text-xs leading-relaxed text-slate-700 dark:border-blue-900/10 dark:bg-slate-950/35 dark:text-slate-300 border-l-4 border-l-blue-600 font-sans">
              "{question.aiSummary}"
              <p className="mt-1.5 text-[9px] font-mono text-blue-500 block tracking-wider uppercase">— Summarized automatically via Gemini AI using community expert sources</p>
            </div>
          ) : (
            <p className="text-xs text-slate-400 leading-relaxed font-sans">
              Too many answers to read through? Press 'Generate AI Summary' to synthesize a compact, institutional response summary automatically.
            </p>
          )}
        </div>
      )}

      {/* 4. Published Answers Grid */}
      <div className="space-y-4">
        <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest leading-none border-b border-slate-100 pb-2 dark:border-slate-800">
          Published Answers
        </h3>

        {answers.length === 0 ? (
          <div className="rounded-xl border border-slate-200 bg-white p-8 text-center text-xs text-slate-400 dark:border-slate-800 dark:bg-slate-950/40">
            No community answer published yet. Be the first volunteer responder to make a contribution!
          </div>
        ) : (
          <div className="space-y-4">
            {answers.map((answer) => {
              const answerAuthorMeta = ROLE_STYLES[answer.authorRole] || ROLE_STYLES['Student/Employee'];
              
              return (
                <div
                  key={answer.id}
                  className={`relative flex items-start gap-4 rounded-xl border p-4 sm:p-5 transition-transform ${
                    answer.isBest
                      ? 'border-amber-200 bg-amber-50/15 dark:border-amber-900/40 dark:bg-amber-950/5'
                      : answer.isVerified
                        ? 'border-emerald-200 bg-emerald-50/10 dark:border-emerald-900/30'
                        : 'border-slate-200 bg-white dark:border-slate-800'
                  }`}
                >
                  {/* Badge ribbons */}
                  {answer.isBest && (
                    <span className="absolute top-4 right-4 flex items-center gap-1 rounded bg-amber-100 dark:bg-amber-950/40 px-2 py-0.5 text-[9px] font-bold text-amber-700 dark:text-amber-400 border border-amber-200">
                      <Award className="h-3 w-3" />
                      <span>Best Answer</span>
                    </span>
                  )}

                  {/* Upvote arrows */}
                  <div className="flex flex-col items-center rounded-lg bg-slate-50 p-1 dark:bg-slate-900/30 mt-1">
                    <button
                      onClick={() => handleVoteAnswer(answer.id, 'up')}
                      className="rounded hover:bg-slate-200/50 p-1 text-slate-400 hover:text-blue-600"
                    >
                      <ArrowBigUp className="h-5 w-5" />
                    </button>
                    <span className="font-mono text-[11px] font-bold my-0.5 text-slate-600 dark:text-slate-400">
                      {answer.votesCount}
                    </span>
                    <button
                      onClick={() => handleVoteAnswer(answer.id, 'down')}
                      className="rounded hover:bg-slate-200/50 p-1 text-slate-400 hover:text-amber-600"
                    >
                      <ArrowBigDown className="h-5 w-5" />
                    </button>
                  </div>

                  {/* Body information */}
                  <div className="flex-1 min-w-0 text-left space-y-3">
                    
                    {/* Header info */}
                    <div className="flex flex-col sm:flex-row sm:items-center gap-1.5 leading-none">
                      <span className="text-xs font-bold text-slate-850 dark:text-gray-100">{answer.authorName}</span>
                      <span className={`text-[8px] rounded px-1.5 py-0.5 leading-none font-mono ${answerAuthorMeta.badgeClass}`}>
                        {answer.authorRole}
                      </span>
                      <span className="text-[10px] text-slate-400 font-mono">• {formatRelativeDate(answer.createdAt)}</span>
                    </div>

                    {/* Body */}
                    <div className="text-xs leading-relaxed text-slate-700 dark:text-slate-300 font-sans whitespace-pre-line">
                      {answer.body}
                    </div>

                    {/* Interaction Buttons Option Row */}
                    <div className="flex flex-wrap items-center gap-2 pt-1">
                      
                      {/* 1. Accepted best trigger (Only original author of question) */}
                      {isQuestionAuthor && (
                        <button
                          onClick={() => handleToggleBestAnswer(answer.id)}
                          className={`flex items-center gap-1 rounded-lg px-2.5 py-1 text-[10px] font-bold border transition-colors cursor-pointer ${
                            answer.isBest
                              ? 'bg-amber-100 text-amber-700 border-amber-300 dark:bg-amber-900 dark:text-amber-250'
                              : 'bg-white hover:bg-amber-50 text-slate-500 border-slate-200 hover:border-amber-200'
                          }`}
                        >
                          <Check className="h-3 w-3" />
                          <span>{answer.isBest ? 'Revoke Best Answer' : 'Accept Best Answer (+20 Reputation)'}</span>
                        </button>
                      )}

                      {/* 2. Verification shield button (Admin/Expert roles only) */}
                      {canVerifyRole && !answer.isVerified && (
                        <button
                          onClick={() => handleVerifyAnswer(answer.id)}
                          className="flex items-center gap-1 rounded-lg border border-emerald-250 bg-emerald-50/20 hover:bg-emerald-58 hover:bg-emerald-50 px-2.5 py-1 text-[10px] font-bold text-emerald-600 cursor-pointer transition-colors"
                        >
                          <ShieldCheck className="h-3 w-3" />
                          <span>Verify Official Policy Answer (+10 Reputation)</span>
                        </button>
                      )}

                      {/* Green checked shield label */}
                      {answer.isVerified && (
                        <span className="flex items-center gap-0.5 rounded-lg bg-emerald-100 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-450 px-2.5 py-1 text-[10px] font-bold border border-emerald-200">
                          <ShieldCheck className="h-3.5 w-3.5" />
                          <span>Verified Answer Code</span>
                        </span>
                      )}

                    </div>

                    {/* 3. Nested Comments Section (Comment list + submission box) */}
                    <div className="border-t border-slate-100 pt-2 space-y-2 dark:border-slate-800">
                      
                      {/* Comments feed list */}
                      <div className="space-y-1.5">
                        {answer.comments && answer.comments.map((comment) => (
                          <div key={comment.id} className="rounded bg-slate-50 p-2 text-[11px] leading-relaxed text-slate-700 dark:bg-slate-900/30 dark:text-slate-300 border border-slate-150">
                            <div className="flex items-center gap-1 font-semibold text-slate-900 dark:text-white pb-0.5">
                              <span>{comment.authorName}</span>
                              <span className="text-[8px] text-slate-400 font-mono">({comment.authorRole})</span>
                              <span className="text-[9px] text-slate-400 font-mono ml-auto">{formatRelativeDate(comment.createdAt)}</span>
                            </div>
                            <p className="font-sans font-normal text-left">{comment.body}</p>
                          </div>
                        ))}
                      </div>

                      {/* Comment Input action form */}
                      {user && (
                        <div className="flex gap-2 items-center">
                          <input
                            type="text"
                            placeholder="Add a nested comment, ask for followups..."
                            value={commentBodies[answer.id] || ''}
                            onChange={(e) => setCommentBodies({ ...commentBodies, [answer.id]: e.target.value })}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                e.preventDefault();
                                handlePostComment(answer.id);
                              }
                            }}
                            className="flex-1 rounded-lg border border-slate-300 p-1.5 text-xs outline-none focus:border-blue-500 dark:border-slate-805 dark:bg-slate-900 text-slate-800 dark:text-slate-200"
                          />
                          <button
                            type="button"
                            disabled={submittingComment[answer.id]}
                            onClick={() => handlePostComment(answer.id)}
                            className="rounded-lg h-[30px] w-[30px] flex items-center justify-center bg-slate-100 hover:bg-blue-100 text-slate-550 hover:text-blue-600 dark:bg-slate-800 cursor-pointer"
                          >
                            <Send className="h-3 w-3" />
                          </button>
                        </div>
                      )}

                    </div>

                  </div>

                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* 5. Post Answer drafting board form */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-950/40">
        <h4 className="text-sm font-bold text-slate-900 dark:text-white">Contribute an Answer</h4>
        <p className="text-xs text-slate-400 mt-1 leading-normal font-sans">
          Provide accurate pathways, document locations, coordinator emails, or timings instructions. Contributing verified, helpful answers awards you Points to level up user badges!
        </p>

        {ansError && (
          <div className="mt-3 rounded-lg bg-rose-50 border border-rose-100 p-2.5 text-xs text-rose-700">
            {ansError}
          </div>
        )}

        <form onSubmit={handlePostAnswer} className="mt-4 space-y-3">
          {user ? (
            <>
              <textarea
                rows={4}
                required
                placeholder="Type your answer, supports code paste and bullet points..."
                value={answerBody}
                onChange={(e) => setAnswerBody(e.target.value)}
                className="w-full rounded-lg border border-slate-300 p-3 text-xs outline-none transition-all placeholder:text-slate-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 dark:border-slate-700 dark:bg-slate-900 text-slate-800 dark:text-slate-200 resize-none font-sans"
              />
              <div className="flex items-center justify-between">
                <span className="text-[10px] text-blue-600 font-semibold uppercase tracking-wider block bg-blue-50/50 dark:bg-blue-950/20 px-2 rounded font-mono">
                  +10 reputation score award on submit!
                </span>
                
                <button
                  type="submit"
                  disabled={submittingAnswer}
                  className="rounded-lg bg-blue-600 px-5 py-2 text-xs font-semibold text-white shadow hover:bg-blue-700 cursor-pointer disabled:bg-slate-400"
                >
                  {submittingAnswer ? 'Publishing...' : 'Publish Answer'}
                </button>
              </div>
            </>
          ) : (
            <div className="rounded-lg border border-dashed border-slate-350 py-6 text-center text-xs text-slate-400 dark:border-slate-800">
              Please{' '}
              <button
                type="button"
                onClick={() => onNavigate('auth')}
                className="font-bold text-blue-600 hover:underline cursor-pointer"
              >
                Sign In
              </button>{' '}
              to draft answer advice sheets on CrowdFAQ.
            </div>
          )}
        </form>
      </div>

    </div>
  );
}
