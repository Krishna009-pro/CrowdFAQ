/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { getInitials, getAvatarGradient, ROLE_STYLES, BADGE_REGISTRY } from '../utils';
import { Edit2, Save, Send, Shield, Info, Star, Flame, Calendar } from 'lucide-react';
import { UserRole } from '../types';

export default function ProfilePage() {
  const { user, token, updateUser } = useAuth();
  
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(user?.name || '');
  const [biography, setBiography] = useState(user?.biography || '');
  const [role, setRole] = useState<UserRole>(user?.role || 'Student/Employee');

  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState<{ text: string; error: boolean } | null>(null);

  // Active hover card state for badges
  const [hoveredBadge, setHoveredBadge] = useState<string | null>(null);

  if (!user) {
    return (
      <div className="rounded-3xl border border-gray-150 bg-white p-12 text-center text-xs text-gray-400 dark:border-gray-850 dark:bg-gray-950/40">
        Authentication required. Please sign in to view your profile dashboard.
      </div>
    );
  }

  const handleProfileSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    setSaving(true);
    setMsg(null);

    try {
      const response = await fetch('/api/v1/auth/profile', {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ name, biography, role })
      });

      const data = await response.json();
      if (response.ok) {
        updateUser(data.user);
        setEditing(false);
        setMsg({ text: 'Profile changes updated successfully!', error: false });
      } else {
        throw new Error(data.error);
      }
    } catch (err: any) {
      setMsg({ text: err.message || 'Failed to modify profile settings.', error: true });
    } finally {
      setSaving(false);
    }
  };

  const roleMeta = ROLE_STYLES[user.role] || ROLE_STYLES['Student/Employee'];

  return (
    <div id="profile-page-container" className="max-w-4xl mx-auto space-y-6 text-left pb-12 select-none">
      
      {/* 1. Header Hero Card */}
      <div className="relative flex flex-col sm:flex-row items-center gap-5 p-6 rounded-xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900/40">
        
        <div className={`flex h-16 w-16 sm:h-20 sm:w-20 items-center justify-center rounded-full bg-gradient-to-tr ${getAvatarGradient(user.name)} text-xl sm:text-2xl font-extrabold text-white shadow-inner`}>
          {getInitials(user.name)}
        </div>

        <div className="flex-1 text-center sm:text-left space-y-1">
          <div className="flex flex-col sm:flex-row sm:items-center justify-center sm:justify-start gap-2">
            <h2 className="text-lg font-bold text-slate-900 dark:text-white sm:text-xl">
              {user.name}
            </h2>
            <span className={`self-center rounded px-2 py-0.5 text-[9px] font-bold tracking-wider uppercase font-mono ${roleMeta.badgeClass}`}>
              {user.role}
            </span>
          </div>

          <p className="text-xs text-slate-500 dark:text-slate-400 italic font-sans max-w-lg">
            "{user.biography || 'No biography details provided.'}"
          </p>

          <div className="flex items-center justify-center sm:justify-start gap-1 py-1 text-[10px] text-slate-400 font-mono">
            <Calendar className="h-3.5 w-3.5" />
            <span>Member registered since {new Date(user.createdAt).toLocaleDateString([], { month: 'short', year: 'numeric' })}</span>
          </div>
        </div>

        <button
          onClick={() => {
            setEditing(!editing);
            setMsg(null);
          }}
          className="rounded-lg bg-slate-50 border border-slate-200 px-4 py-2 text-xs font-bold text-slate-700 hover:bg-slate-100 dark:bg-slate-800 dark:border-slate-700 dark:text-slate-200 cursor-pointer"
        >
          {editing ? 'Cancel' : 'Edit Profile'}
        </button>

      </div>

      {msg && (
        <div className={`rounded-lg p-3 text-xs font-semibold ${msg.error ? 'bg-rose-50 text-rose-700 border border-rose-100' : 'bg-green-50 text-green-700 border border-green-100 dark:bg-green-950/20 dark:border-green-900/40'}`}>
          {msg.text}
        </div>
      )}

      {/* 2. Interactive Editing Form Panel */}
      {editing && (
        <div className="rounded-xl border border-slate-200 bg-white p-5 shadow dark:border-slate-800 dark:bg-slate-900/40">
          <h4 className="text-sm font-bold text-slate-900 dark:text-white border-b border-slate-100 pb-2 mb-4 dark:border-slate-800">
            Edit Biography & Testing Role Settings
          </h4>
          <form onSubmit={handleProfileSave} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-slate-400 mb-1.5 font-mono">Full Display Name</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 h-10 p-2.5 text-sm dark:border-slate-700 dark:bg-slate-900 outline-none focus:border-blue-500 text-slate-800 dark:text-slate-200"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-400 mb-1.5 font-mono">Testing Role (Simulate permissions!)</label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value as UserRole)}
                  className="w-full rounded-lg border border-slate-300 h-10 pr-4 pl-2 text-sm dark:border-slate-700 dark:bg-slate-900 outline-none focus:border-blue-500 text-slate-800 dark:text-slate-200 bg-white"
                >
                  <option value="Student/Employee">Student/Employee (Standard)</option>
                  <option value="Expert">Expert (Can officially verify answers)</option>
                  <option value="Admin">Admin (Can officially verify answers & view analytics)</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-400 mb-1.5 font-mono">Bio Details</label>
              <textarea
                rows={3}
                value={biography}
                onChange={(e) => setBiography(e.target.value)}
                className="w-full rounded-lg border border-slate-300 p-2 text-sm dark:border-slate-700 dark:bg-slate-900 outline-none focus:border-blue-500 text-slate-800 dark:text-slate-200 resize-none font-sans"
              />
            </div>

            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setEditing(false)}
                className="rounded-lg bg-slate-100 px-4 py-2 text-xs font-bold text-slate-500 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={saving}
                className="rounded-lg bg-blue-600 px-5 py-2 text-xs font-semibold text-white hover:bg-blue-700 cursor-pointer shadow-sm"
              >
                {saving ? 'Updating...' : 'Save Settings'}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* 3. Metrics grid */}
      <div className="grid grid-cols-2 gap-4">
        <div className="rounded-xl border border-slate-200 bg-white p-5 text-center dark:border-slate-800 dark:bg-slate-900/40 flex flex-col items-center justify-center shadow-sm">
          <Flame className="h-6 w-6 text-orange-500 mb-1 animate-pulse" />
          <span className="text-xl font-mono font-bold text-slate-900 dark:text-white leading-none">{user.points} pts</span>
          <span className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider mt-1 block font-mono">Reputation Score</span>
        </div>
        <div className="rounded-xl border border-slate-200 bg-white p-5 text-center dark:border-slate-800 dark:bg-slate-900/40 flex flex-col items-center justify-center shadow-sm">
          <Star className="h-6 w-6 text-amber-500 mb-1" />
          <span className="text-xl font-mono font-bold text-slate-900 dark:text-white leading-none">{user.badges.length} badges</span>
          <span className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider mt-1 block font-mono">Unlocked achievements</span>
        </div>
      </div>

      {/* 4. Earned Badges Shelf (hover details cards Dev 7 requirements) */}
      <div className="rounded-xl border border-slate-200 bg-white p-5 shadow-sm dark:border-slate-800 dark:bg-slate-900/40 space-y-4">
        
        <div>
          <h3 className="text-sm font-bold text-slate-900 dark:text-white leading-tight">Digital Achievements Shelf</h3>
          <p className="text-xs text-slate-400 mt-1 leading-normal font-sans">
            Unlocked honors representing your community service levels. Hover over any badge to see detailed descriptions and score requirements!
          </p>
        </div>

        {/* Badges Flex Grid */}
        <div className="relative grid grid-cols-2 gap-3 sm:grid-cols-5">
          {Object.keys(BADGE_REGISTRY).map((badgeKey) => {
            const b = BADGE_REGISTRY[badgeKey];
            const isUnlocked = user.badges.some(ub => ub.toLowerCase() === b.name.toLowerCase()) || 
                               (b.name === 'Policy Maker' && user.role === 'Admin');

            return (
              <div
                key={b.name}
                onMouseEnter={() => setHoveredBadge(b.name)}
                onMouseLeave={() => setHoveredBadge(null)}
                className={`relative flex flex-col items-center p-4 border rounded-xl transition-all cursor-help ${
                  isUnlocked
                    ? 'border-blue-100 bg-blue-50/10 dark:border-blue-900/50 dark:bg-blue-950/15 scale-100 hover:shadow-md'
                    : 'border-slate-100 bg-slate-50/50 opacity-40 dark:border-slate-800 saturate-0'
                }`}
              >
                {/* Badge Emoji */}
                <span className="text-3xl leading-none filter drop-shadow">{b.emoji}</span>
                <span className="mt-2 text-[10px] font-bold text-slate-800 dark:text-slate-200 text-center truncate w-full">{b.name}</span>
                <span className={`mt-1.5 text-[8px] font-semibold text-center uppercase tracking-wider block font-mono ${isUnlocked ? 'text-blue-600' : 'text-slate-400'}`}>
                  {isUnlocked ? 'Unlocked' : 'Locked'}
                </span>
              </div>
            );
          })}
        </div>

        {/* Hover Explainer Panel - custom card popup */}
        <div className="min-h-20 relative p-3 border border-blue-105 border-dashed rounded-xl bg-blue-50/5 dark:border-blue-950/10 dark:bg-blue-950/5 flex flex-col justify-center">
          {hoveredBadge ? (
            (() => {
              const b = BADGE_REGISTRY[hoveredBadge];
              const isUnlocked = user.badges.some(ub => ub.toLowerCase() === b.name.toLowerCase()) || 
                                 (b.name === 'Policy Maker' && user.role === 'Admin');
              return (
                <div className="space-y-1">
                  <div className="flex items-center gap-1 text-xs font-bold text-blue-600 dark:text-blue-400">
                    <span>{b.emoji}</span>
                    <span className="uppercase tracking-widest font-mono">{b.name} Achievement</span>
                    <span className="text-[9px] text-slate-400 font-normal ml-auto font-mono">
                      ({isUnlocked ? 'Completed' : 'Candidate'})
                    </span>
                  </div>
                  <p className="text-xs text-slate-700 dark:text-slate-300 font-sans font-normal">
                    {b.description}
                  </p>
                  <p className="text-[10px] text-slate-400 font-mono italic">
                    How it is earned: {b.requirement}
                  </p>
                </div>
              );
            })()
          ) : (
            <div className="flex items-center gap-1.5 justify-center py-2 text-xs text-slate-400 font-mono">
              <Info className="h-4 w-4 text-blue-500" />
              <span>Hover over any badge block to preview achievement requirements.</span>
            </div>
          )}
        </div>

      </div>

    </div>
  );
}
