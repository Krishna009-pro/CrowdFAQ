/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Question } from '../types';
import { useAuth } from '../context/AuthContext';
import { getInitials, getAvatarGradient, formatRelativeDate, ROLE_STYLES } from '../utils';
import { ArrowBigUp, ArrowBigDown, MessageCircle, Eye, Tag, AlertCircle } from 'lucide-react';

interface QuestionCardProps {
  key?: string | number;
  question: Question;
  onNavigate: (page: string, params?: any) => void;
  onVoteSuccess?: () => any;
}

export default function QuestionCard({ question, onNavigate, onVoteSuccess }: QuestionCardProps) {
  const { user, token } = useAuth();
  const [votesCount, setVotesCount] = useState(question.votesCount);
  const [currentUserVote, setCurrentUserVote] = useState<'up' | 'down' | null>(
    user ? (question.votes && question.votes[user.id] ? question.votes[user.id] : null) : null
  );
  const [voting, setVoting] = useState(false);

  const handleVote = async (dir: 'up' | 'down', e: React.MouseEvent) => {
    e.stopPropagation();
    if (!token) {
      alert('Authentication is required to vote on FAQs.');
      onNavigate('auth');
      return;
    }

    if (voting) return;
    setVoting(true);

    try {
      const response = await fetch(`/api/v1/questions/${question.id}/vote`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ dir })
      });

      if (response.ok) {
        const data = await response.json();
        setVotesCount(data.question.votesCount);
        
        // Toggle client state
        if (currentUserVote === dir) {
          setCurrentUserVote(null);
        } else {
          setCurrentUserVote(dir);
        }

        if (onVoteSuccess) onVoteSuccess();
      }
    } catch (e) {
      console.error('Failed to vote:', e);
    } finally {
      setVoting(false);
    }
  };

  const roleMeta = ROLE_STYLES[question.authorRole] || ROLE_STYLES['Student/Employee'];

  return (
    <div
      onClick={() => onNavigate('question-detail', { id: question.id })}
      className="group relative flex items-start gap-4 rounded-xl border border-slate-200 bg-white p-5 transition-all hover:border-blue-300 hover:shadow-md dark:border-slate-800 dark:bg-slate-900/40 select-none cursor-pointer"
    >
      
      {/* 1. Vote Control Panel (arrows lighting up Blue/Amber) */}
      <div className="flex flex-col items-center rounded-lg bg-slate-50 p-1.5 dark:bg-slate-900/50">
        <button
          onClick={(e) => handleVote('up', e)}
          className={`rounded-md p-1 transition-all ${
            currentUserVote === 'up'
              ? 'text-blue-600 bg-blue-50 dark:bg-blue-950/40'
              : 'text-slate-400 hover:text-slate-650'
          }`}
          title="Upvote good questions"
        >
          <ArrowBigUp className="h-6 w-6 stroke-[1.5]" />
        </button>
        <span className={`font-mono text-xs font-bold leading-none my-1 ${
          currentUserVote === 'up' 
            ? 'text-blue-600' 
            : currentUserVote === 'down' 
              ? 'text-amber-600' 
              : 'text-slate-600 dark:text-slate-400'
        }`}>
          {votesCount}
        </span>
        <button
          onClick={(e) => handleVote('down', e)}
          className={`rounded-md p-1 transition-all ${
            currentUserVote === 'down'
              ? 'text-amber-600 bg-amber-50 dark:bg-amber-950/40'
              : 'text-slate-400 hover:text-slate-650'
          }`}
          title="Downvote unhelpful questions"
        >
          <ArrowBigDown className="h-6 w-6 stroke-[1.5]" />
        </button>
      </div>

      {/* 2. Questions content container */}
      <div className="flex-1 min-w-0 text-left space-y-2">
        
        {/* Author / Category bar */}
        <div className="flex flex-wrap items-center justify-between gap-2">
          
          <div className="flex items-center gap-2">
            <div className={`flex h-6.5 w-6.5 items-center justify-center rounded-lg bg-gradient-to-tr ${getAvatarGradient(question.authorName)} text-[10px] font-bold text-white`}>
              {getInitials(question.authorName)}
            </div>
            <div className="flex flex-col sm:flex-row sm:items-center gap-1 leading-none">
              <span className="text-xs font-bold text-slate-800 dark:text-slate-200">{question.authorName}</span>
              <span className={`rounded px-1.5 py-0.5 text-[8.5px] font-mono leading-none ${roleMeta.badgeClass}`}>
                {question.authorRole}
              </span>
            </div>
            <span className="text-[10px] text-slate-400 font-mono">• {formatRelativeDate(question.createdAt)}</span>
          </div>

          <span className="rounded bg-blue-50/70 px-2 py-0.5 text-[10px] font-semibold text-blue-700 dark:bg-blue-950/30 dark:text-blue-400 border border-blue-100/50 dark:border-blue-900/40">
            #{question.category}
          </span>
        </div>

        {/* Title and Short descriptions */}
        <div className="space-y-1">
          <h4 className="text-sm font-bold tracking-tight text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors line-clamp-2">
            {question.title}
          </h4>
          <p className="text-xs text-slate-500 dark:text-slate-450 line-clamp-2 leading-relaxed">
            {question.description}
          </p>
        </div>

        {/* Duplicate warning label */}
        {question.isDuplicate && (
          <div className="flex items-center gap-1 text-[11px] font-semibold text-amber-600 dark:text-amber-450">
            <AlertCircle className="h-3.5 w-3.5" />
            <span>Marked as duplicate of: {question.duplicateOfTitle}</span>
          </div>
        )}

        {/* Bottom tags & metrics row */}
        <div className="flex flex-wrap items-center gap-3 border-t border-slate-100 pt-2.5 dark:border-slate-800/60">
          
          {/* Tags preview */}
          <div className="flex flex-wrap gap-1">
            {question.tags.map(t => (
              <span key={t} className="flex items-center gap-0.5 rounded bg-slate-100 px-1.5 py-0.5 text-[9.5px] font-mono text-slate-500 dark:bg-slate-900 dark:text-slate-450">
                <Tag className="h-2.5 w-2.5 text-slate-450" />
                <span>{t}</span>
              </span>
            ))}
          </div>

          {/* Views + Answers metrics */}
          <div className="ml-auto flex items-center gap-3 text-[11px] font-semibold text-slate-400">
            <div className="flex items-center gap-1" title="Views counter">
              <Eye className="h-3.5 w-3.5" />
              <span>{question.viewsCount} views</span>
            </div>
            <div className="flex items-center gap-1" title="Answers total count">
              <MessageCircle className="h-3.5 w-3.5" />
              <span className={question.answersCount > 0 ? "text-blue-600 dark:text-blue-450" : ""}>
                {question.answersCount} answers
              </span>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
}
