/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../context/AuthContext';
import { Sparkles, MessageCircle, X, Send, Bot, HelpCircle } from 'lucide-react';
import { ChatMessage } from '../types';

export default function AIChatbotWidget() {
  const { token, user } = useAuth();
  
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'welcome',
      role: 'assistant',
      text: 'Hello! I am CrowdBot, your placements and academic FAQ guide. Ask me questions like: "Where is the placement office?" or "How do I apply for the IIT Ropar internship?"',
      createdAt: new Date().toISOString()
    }
  ]);
  
  const [inputVal, setInputVal] = useState('');
  const [loading, setLoading] = useState(false);
  const [sessionId] = useState(() => 'sess_' + Math.random().toString(36).substring(2, 11));

  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto-scroll on new message
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!token) {
      alert('Authentication is required to converse with CrowdBot.');
      return;
    }

    const trimmed = inputVal.trim();
    if (!trimmed || loading) return;

    // Append user message
    const userMsg: ChatMessage = {
      id: 'u_' + Math.random().toString(36).substring(2, 9),
      role: 'user',
      text: trimmed,
      createdAt: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMsg]);
    setInputVal('');
    setLoading(true);

    try {
      const response = await fetch('/api/v1/chatbot/query', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ message: trimmed, sessionId })
      });

      if (response.ok) {
        const data = await response.json();
        const botMsg: ChatMessage = {
          id: 'b_' + Math.random().toString(36).substring(2, 9),
          role: 'assistant',
          text: data.reply,
          createdAt: new Date().toISOString()
        };
        setMessages(prev => [...prev, botMsg]);
      } else {
        throw new Error();
      }
    } catch {
      setMessages(prev => [
        ...prev,
        {
          id: 'err_' + Date.now(),
          role: 'assistant',
          text: 'I ran into issues querying my RAG index. Please log in and make sure your API keys are registered.',
          createdAt: new Date().toISOString()
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  if (!user) return null; // Chat assistant only available to authenticated members limit

  return (
    <div id="ai-chatbot-widget" className="fixed bottom-6 right-6 z-50">
      <AnimatePresence>
        
        {/* Chat Window Panel */}
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.85, y: 30 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.85, y: 30 }}
            transition={{ duration: 0.18 }}
            className="mb-4 flex flex-col w-80 sm:w-96 h-112 rounded-xl border border-slate-200 bg-white shadow-2xl dark:border-slate-800 dark:bg-slate-950 overflow-hidden text-left"
          >
            
            {/* Header branding */}
            <div className="flex items-center justify-between bg-blue-600 p-4 text-white">
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-white/15">
                  <Bot className="h-4.5 w-4.5 text-white animate-pulse" />
                </div>
                <div>
                  <h4 className="text-xs font-bold leading-none">CrowdBot AI Agent</h4>
                  <span className="text-[9px] text-blue-105 font-mono mt-0.5 block tracking-wider uppercase">Institutional RAG Helper</span>
                </div>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="rounded-lg p-1 hover:bg-white/10"
              >
                <X className="h-4.5 w-4.5" />
              </button>
            </div>

            {/* Message Feed lists */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3 select-text bg-slate-50/20 dark:bg-slate-950/25 font-sans">
              {messages.map((m) => (
                <div
                  key={m.id}
                  className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[85%] rounded-xl px-3 py-2 text-xs leading-normal font-sans text-left ${
                      m.role === 'user'
                        ? 'bg-blue-600 font-semibold text-white rounded-br-none shadow-sm'
                        : 'bg-slate-100 text-slate-800 dark:bg-slate-900 dark:text-slate-200 rounded-bl-none border border-slate-200/50 dark:border-slate-800/60'
                    }`}
                  >
                    {m.text}
                  </div>
                </div>
              ))}
              
              {loading && (
                <div className="flex justify-start">
                  <div className="rounded-xl rounded-bl-none bg-slate-100 p-3 text-xs dark:bg-slate-900 border border-slate-200/50 dark:border-slate-800/60 flex items-center gap-1">
                    <span className="size-1.5 animate-bounce rounded-full bg-blue-600" />
                    <span className="size-1.5 animate-bounce rounded-full bg-blue-600 delay-150" />
                    <span className="size-1.5 animate-bounce rounded-full bg-blue-600 delay-300" />
                  </div>
                </div>
              )}
              <div ref={scrollRef} />
            </div>

            {/* Form actions widget */}
            <form onSubmit={handleSendMessage} className="p-3 border-t border-slate-100 bg-white dark:border-slate-800 dark:bg-slate-950">
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="Ask placement office location, transcripts..."
                  value={inputVal}
                  onChange={(e) => setInputVal(e.target.value)}
                  className="flex-1 rounded-lg border border-slate-300 p-2 text-xs outline-none focus:border-blue-500 dark:border-slate-800 dark:bg-slate-900 text-slate-850 dark:text-slate-200"
                />
                <button
                  type="submit"
                  disabled={loading || !inputVal.trim()}
                  className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-600 hover:bg-blue-700 disabled:bg-slate-200 text-white cursor-pointer"
                >
                  <Send className="h-4 w-4" />
                </button>
              </div>
            </form>

          </motion.div>
        )}
      </AnimatePresence>

      {/* Floating Action Trigger Button */}
      <motion.button
        id="btn-chatbot-float"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen(!isOpen)}
        className="flex h-12 w-12 items-center justify-center rounded-xl bg-blue-600 text-white shadow-xl hover:bg-blue-750 cursor-pointer"
      >
        {isOpen ? <X className="h-5.5 w-5.5" /> : <Sparkles className="h-5.5 w-5.5 animate-pulse" />}
      </motion.button>

    </div>
  );
}
