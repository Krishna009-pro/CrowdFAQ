/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../context/AuthContext';
import { X, Sparkles, AlertTriangle, CloudRain, Plus, ArrowRight } from 'lucide-react';

interface AskQuestionModalProps {
  onClose: () => void;
  onQuestionCreated: (newQuestion: any) => void;
  onNavigate: (page: string, params?: any) => void;
}

export default function AskQuestionModal({ onClose, onQuestionCreated, onNavigate }: AskQuestionModalProps) {
  const { token } = useAuth();
  
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('General');
  
  // Tag Pills states
  const [tempTag, setTempTag] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // AI states
  const [duplicateLoading, setDuplicateLoading] = useState(false);
  const [duplicateWarning, setDuplicateWarning] = useState<{
    isDuplicate: boolean;
    matchedQuestionId?: string;
    matchedQuestionTitle?: string;
    explanation?: string;
  } | null>(null);
  
  const [aiTagLoading, setAiTagLoading] = useState(false);

  // Debounced duplicate checking triggered on title length
  useEffect(() => {
    if (title.trim().length < 15) {
      setDuplicateWarning(null);
      return;
    }

    const delayDebounce = setTimeout(async () => {
      setDuplicateLoading(true);
      try {
        const response = await fetch('/api/v1/questions/duplicate-check', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify({ title, description })
        });
        if (response.ok) {
          const result = await response.json();
          setDuplicateWarning(result);
        }
      } catch (e) {
        console.warn('Silent fallback on duplicate-check:', e);
      } finally {
        setDuplicateLoading(false);
      }
    }, 1200);

    return () => clearTimeout(delayDebounce);
  }, [title, description, token]);

  const handleAddTag = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const clean = tempTag.trim().toLowerCase().replace(/^#/, '');
    if (clean && !tags.includes(clean) && tags.length < 5) {
      setTags([...tags, clean]);
      setTempTag('');
    }
  };

  const handleRemoveTag = (indexToRemove: number) => {
    setTags(tags.filter((_, i) => i !== indexToRemove));
  };

  // 1-Click AI Auto Tag Filling!
  const triggerAiAutoTags = async () => {
    if (!title) {
      setError('Please provide a short draft title first so Gemini can analyze context!');
      return;
    }
    setAiTagLoading(true);
    setError(null);
    try {
      const response = await fetch('/api/v1/questions/suggest-tags', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ title, description })
      });
      if (response.ok) {
        const result = await response.json();
        if (result.category) setCategory(result.category);
        if (Array.isArray(result.tags)) {
          // Merge unique suggested tags
          setTags(Array.from(new Set([...tags, ...result.tags])).slice(0, 5));
        }
      } else {
        throw new Error('AI tag indexing returned an error.');
      }
    } catch (err: any) {
      setError(err.message || 'Heuristics tags failed to trigger.');
    } finally {
      setAiTagLoading(false);
    }
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) {
      setError('Title and Description are required attributes.');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/v1/questions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ title, description, category, tags })
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to publish information.');
      }

      onQuestionCreated(data.question);
      onClose();
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div id="ask-modal-box" className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Black ambient backdrop glass */}
      <div className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm" onClick={onClose} />
      
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 15 }}
        className="relative z-10 w-full max-w-lg overflow-hidden rounded-xl border border-slate-200 bg-white p-5 shadow-2xl dark:border-slate-805 dark:bg-slate-900 sm:p-7 max-h-[92vh] overflow-y-auto"
      >
        
        {/* Header toolbar */}
        <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-4 dark:border-slate-800">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-blue-50 text-blue-600 dark:bg-blue-950/40 dark:text-blue-400">
              <Sparkles className="h-4.5 w-4.5" />
            </div>
            <h3 className="font-heading text-base font-bold text-slate-900 dark:text-white">Centralize Community FAQ</h3>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg p-1.5 text-slate-400 hover:bg-slate-50 hover:text-slate-700 dark:hover:bg-slate-800 dark:hover:text-slate-200 cursor-pointer"
          >
            <X className="h-4.5 w-4.5" />
          </button>
        </div>

        {error && (
          <div className="mb-4 rounded-lg bg-rose-50 border border-rose-100 p-3 text-xs text-rose-700 dark:bg-rose-950/20 dark:border-rose-900/40">
            {error}
          </div>
        )}

        <form onSubmit={handleFormSubmit} className="space-y-4 text-left">
          
          {/* Question title */}
          <div>
            <label className="block text-xs font-bold text-slate-400 dark:text-slate-500 mb-1">
              Question Title
            </label>
            <input
              type="text"
              required
              placeholder='e.g., How do I apply for the IIT Ropar internship program?'
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full rounded-lg border border-slate-300 p-2.5 text-sm outline-none transition-all placeholder:text-slate-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 dark:border-slate-700 dark:bg-slate-900 dark:focus:border-blue-400 dark:focus:ring-blue-950 text-slate-800 dark:text-slate-200"
            />
          </div>

          {/* Question description */}
          <div>
            <label className="block text-xs font-bold text-slate-400 dark:text-slate-500 mb-1">
              Detailed Context / Body
            </label>
            <textarea
              required
              rows={4}
              placeholder="Provide a detailed outline of background details, transcripts, link directions, or specific placement sheets..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full rounded-lg border border-slate-300 p-2.5 text-sm outline-none transition-all placeholder:text-slate-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-100 dark:border-slate-700 dark:bg-slate-900 dark:focus:border-blue-400 dark:focus:ring-blue-950 text-slate-800 dark:text-slate-200 font-sans"
            />
          </div>

          {/* Real-time duplicate check alert */}
          <AnimatePresence>
            {duplicateLoading && (
              <div className="flex items-center gap-2 text-xs text-slate-400 py-1 font-mono">
                <span className="size-3 animate-spin rounded-full border-2 border-blue-600 border-t-transparent" />
                <span>Scanning catalog duplicate matches...</span>
              </div>
            )}
            {duplicateWarning && duplicateWarning.isDuplicate && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="overflow-hidden"
              >
                <div className="rounded-lg border border-amber-200 bg-amber-50/50 p-3.5 text-xs text-amber-800 dark:border-amber-900/40 dark:bg-amber-950/20 dark:text-amber-450 space-y-2">
                  <div className="flex items-center gap-1.5 font-bold">
                    <AlertTriangle className="h-4 w-4 text-amber-505" />
                    <span>Duplicate Detected!</span>
                  </div>
                  <p>{duplicateWarning.explanation}</p>
                  <p className="font-semibold text-slate-700 dark:text-slate-300">
                    Existing thread: "{duplicateWarning.matchedQuestionTitle}"
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      onNavigate('question-detail', { id: duplicateWarning.matchedQuestionId });
                      onClose();
                    }}
                    className="flex items-center gap-1 font-bold text-blue-600 hover:underline cursor-pointer pt-1"
                  >
                    <span>Read existing answers immediately instead</span>
                    <ArrowRight className="h-3 w-3" />
                  </button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>

          {/* Category selection & Suggest AI Buttons */}
          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            <div>
              <label className="block text-xs font-bold text-slate-400 dark:text-slate-500 mb-1">
                Category Folder
              </label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white p-2.5 text-sm outline-none dark:border-slate-700 dark:bg-slate-900 text-slate-800 dark:text-slate-200"
              >
                {['General', 'Admissions', 'Placements', 'Scholarships', 'Academics'].map((cat) => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>

            {/* AI Assistant button */}
            <div className="flex flex-col justify-end">
              <button
                type="button"
                onClick={triggerAiAutoTags}
                disabled={aiTagLoading}
                className="flex items-center justify-center gap-1.5 rounded-lg border border-blue-200 bg-blue-50/50 px-4 py-2.5 text-xs font-bold text-blue-700 hover:bg-blue-100 dark:border-blue-900/40 dark:bg-blue-950/10 dark:text-blue-300 cursor-pointer disabled:bg-slate-100"
              >
                <Sparkles className="h-4 w-4 text-blue-600" />
                <span>{aiTagLoading ? 'Auto-suggesting...' : 'AI Suggest Tags & Category'}</span>
              </button>
            </div>
          </div>

          {/* Dynamic input tags capsules */}
          <div>
            <label className="block text-xs font-bold text-slate-400 dark:text-slate-500 mb-1">
              Topic Tags (Max 5)
            </label>
            <div className="flex flex-wrap gap-1.5 mb-2">
              {tags.map((tag, i) => (
                <span
                  key={tag}
                  className="flex items-center gap-1 rounded bg-blue-50 pl-2.5 pr-1.5 py-0.5 text-xs font-semibold text-blue-700 dark:bg-blue-950/40 dark:text-blue-450 border border-blue-100"
                >
                  <span>#{tag}</span>
                  <button
                    type="button"
                    onClick={() => handleRemoveTag(i)}
                    className="rounded p-0.5 hover:bg-blue-100 dark:hover:bg-blue-900"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </span>
              ))}
              {tags.length === 0 && (
                <span className="text-xs text-slate-400 py-1 font-mono">No tags selected. Type one below and hit Enter!</span>
              )}
            </div>

            {tags.length < 5 && (
              <div className="flex gap-2">
                <input
                  type="text"
                  placeholder="e.g., placements (Press Enter to add)"
                  value={tempTag}
                  onChange={(e) => setTempTag(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddTag();
                    }
                  }}
                  className="flex-1 rounded-lg border border-slate-300 p-2 text-xs outline-none focus:border-blue-500 dark:border-slate-700 dark:bg-slate-900 text-slate-800 dark:text-slate-200"
                />
                <button
                  type="button"
                  onClick={() => handleAddTag()}
                  className="rounded-lg bg-slate-100 hover:bg-slate-200 px-3 text-xs font-bold text-slate-700 dark:bg-slate-800 dark:hover:bg-slate-750 dark:text-slate-200 cursor-pointer"
                >
                  <Plus className="h-3.5 w-3.5" />
                </button>
              </div>
            )}
          </div>

          {/* Publishers triggers */}
          <div className="border-t border-slate-100 pt-4 mt-6 flex justify-end gap-2 dark:border-slate-800">
            <button
              type="button"
              onClick={onClose}
              className="rounded-lg bg-slate-105 bg-slate-100 px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-755 dark:text-slate-300 cursor-pointer"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="rounded-lg bg-blue-600 px-5 py-2 text-xs font-medium text-white shadow-md hover:bg-blue-700 disabled:bg-slate-400 cursor-pointer"
            >
              {loading ? 'Publishing...' : 'Publish Question'}
            </button>
          </div>

        </form>

      </motion.div>
    </div>
  );
}
