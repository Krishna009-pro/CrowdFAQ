/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { motion } from 'motion/react';
import { Mail, User, Lock, BookOpen, PenTool } from 'lucide-react';
import { ROLE_STYLES } from '../utils';

interface AuthPageProps {
  onNavigate: (page: string) => void;
}

export default function AuthPage({ onNavigate }: AuthPageProps) {
  const { login } = useAuth();
  const [isLogin, setIsLogin] = useState(true);
  
  // Registration States
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<'Student/Employee' | 'Expert' | 'Admin'>('Student/Employee');
  const [biography, setBiography] = useState('');

  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    const endpoint = isLogin ? '/api/v1/auth/login' : '/api/v1/auth/register';
    const body = isLogin 
      ? { email, password }
      : { email, name, password, role, biography };

    try {
      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Authentication process failed.');
      }

      login(data.token, data.user);
      onNavigate('feed');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div id="auth-screen" className="flex min-h-[calc(100vh-4rem)] items-center justify-center p-6 bg-slate-50/50 dark:bg-slate-950/20">
      <div className="w-full max-w-md rounded-xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-805 dark:bg-slate-900/40 sm:p-8">
        
        {/* Branding header inside app */}
        <div className="flex flex-col items-center text-center">
          <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-blue-600 shadow-sm">
            <BookOpen className="h-5.5 w-5.5 text-white" />
          </div>
          <h2 className="mt-4 font-heading text-lg font-bold tracking-tight text-slate-900 dark:text-white">
            {isLogin ? 'Log in to CrowdFAQ' : 'Join CrowdFAQ Community'}
          </h2>
          <p className="mt-1.5 text-xs text-slate-400 dark:text-slate-500 font-sans">
            {isLogin ? 'Welcome back! Sign in to ask and answer community FAQs.' : 'Create an account and start building your reputation score!'}
          </p>
        </div>

        {error && (
          <div className="mt-5 rounded-lg bg-rose-50 border border-rose-100 p-3.5 text-xs text-rose-700 dark:bg-rose-950/20 dark:border-rose-900/40 dark:text-rose-400">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-6 flex flex-col gap-4">
          
          {/* Your Full Name field (Register only) */}
          {!isLogin && (
            <div className="relative">
              <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-550 mb-1.5 font-mono">Your Full Name</label>
              <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                  <User className="h-4 w-4 text-slate-400" />
                </div>
                <input
                  type="text"
                  required
                  placeholder="Neha Sharma"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 py-2 pl-9 pr-4 text-xs h-9.5 outline-none transition-all focus:border-blue-500 focus:ring-2 focus:ring-blue-100 dark:border-slate-800 dark:bg-slate-900 text-slate-800 dark:text-slate-200"
                />
              </div>
            </div>
          )}

          {/* Email Address */}
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-550 mb-1.5 font-mono">Email Address</label>
            <div className="relative">
              <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                <Mail className="h-4 w-4 text-slate-400" />
              </div>
              <input
                type="email"
                required
                placeholder="student@crowdfaq.edu"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full rounded-lg border border-slate-300 py-2 pl-9 pr-4 text-xs h-9.5 outline-none transition-all focus:border-blue-500 focus:ring-2 focus:ring-blue-100 dark:border-slate-800 dark:bg-slate-900 text-slate-800 dark:text-slate-200"
              />
            </div>
          </div>

          {/* Biographies description (Register only) */}
          {!isLogin && (
            <div>
              <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-550 mb-1.5 font-mono">Short Biography</label>
              <div className="relative">
                <div className="pointer-events-none absolute inset-y-0 left-0 flex items-start pl-3 pt-3">
                  <PenTool className="h-4 w-4 text-slate-400" />
                </div>
                <textarea
                  placeholder="I am a CS student volunteer interested in tech placements..."
                  rows={2}
                  value={biography}
                  onChange={(e) => setBiography(e.target.value)}
                  className="w-full rounded-lg border border-slate-300 py-2.5 pl-9 pr-4 text-xs outline-none transition-all focus:border-blue-500 focus:ring-2 focus:ring-blue-100 dark:border-slate-800 dark:bg-slate-900 text-slate-800 dark:text-slate-200 resize-none font-sans"
                />
              </div>
            </div>
          )}

          {/* Password */}
          <div>
            <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-550 mb-1.5 font-mono">Password</label>
            <div className="relative">
              <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                <Lock className="h-4 w-4 text-slate-400" />
              </div>
              <input
                type="password"
                required
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full rounded-lg border border-slate-300 py-2 pl-9 pr-4 text-xs h-9.5 outline-none transition-all focus:border-blue-500 focus:ring-2 focus:ring-blue-100 dark:border-slate-800 dark:bg-slate-900 text-slate-850 dark:text-slate-200"
              />
            </div>
          </div>

          {/* Role selector (Register only) */}
          {!isLogin && (
            <div>
              <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 dark:text-slate-550 mb-2 font-mono font-mono">Select Community Role</label>
              <div className="grid grid-cols-2 gap-2 text-left">
                {(['Student/Employee', 'Expert'] as const).map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setRole(r)}
                    className={`flex flex-col p-2.5 rounded-lg border transition-all text-left cursor-pointer ${
                      role === r
                        ? 'border-blue-600 bg-blue-50/20 dark:bg-indigo-950/20 ring-2 ring-blue-100 dark:ring-blue-900'
                        : 'border-slate-200 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-905'
                    }`}
                  >
                    <span className="text-xs font-semibold text-slate-800 dark:text-gray-200">{r}</span>
                    <span className="text-[9px] text-slate-400 mt-1 leading-normal font-sans">
                      {r === 'Expert' ? 'Student guide lead / mentor' : 'Standard reader & answers writer'}
                    </span>
                  </button>
                ))}
              </div>
              {/* Note that Admin can be configured inside profile or fallback */}
              <div className="mt-2.5 text-[9px] text-slate-400 text-center font-mono font-mono">
                Need Admin role? Register & shift role inside your Profile page anytime!
              </div>
            </div>
          )}

          {/* Submit Trigger */}
          <button
            type="submit"
            disabled={loading}
            className="mt-2 flex w-full items-center justify-center rounded-lg bg-blue-600 py-2.5 text-xs font-semibold text-white shadow-sm hover:bg-blue-700 focus:outline-none disabled:bg-slate-300 cursor-pointer"
          >
            {loading ? 'Authenticating...' : isLogin ? 'Sign In Now' : 'Create Community Account'}
          </button>
        </form>

        <div className="mt-5 text-center text-xs">
          <span className="text-slate-400 font-sans">
            {isLogin ? "Don't have a CrowdFAQ account?" : 'Already registered?'}
          </span>{' '}
          <button
            onClick={() => {
              setIsLogin(!isLogin);
              setError(null);
            }}
            className="font-bold text-blue-600 hover:underline cursor-pointer"
          >
            {isLogin ? 'Sign Up' : 'Log In'}
          </button>
        </div>

      </div>
    </div>
  );
}
