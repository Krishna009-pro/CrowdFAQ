/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types';

interface AuthContextType {
  token: string | null;
  user: User | null;
  loading: boolean;
  login: (token: string, user: User) => void;
  logout: () => void;
  updateUser: (updatedUser: User) => void;
  notifications: any[];
  refreshNotifications: () => Promise<void>;
  markNotificationsRead: () => Promise<void>;
  theme: 'light' | 'dark';
  toggleTheme: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [token, setToken] = useState<string | null>(localStorage.getItem('crowdfaq_token'));
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [theme, setTheme] = useState<'light' | 'dark'>((localStorage.getItem('crowdfaq_theme') as 'light' | 'dark') || 'light');

  // Sync token loading
  useEffect(() => {
    async function loadProfile() {
      if (!token) {
        setLoading(false);
        return;
      }

      try {
        const response = await fetch('/api/v1/auth/profile', {
          headers: {
            'Authorization': `Bearer ${token}`,
          },
        });
        if (response.ok) {
          const data = await response.json();
          setUser(data.user);
        } else {
          // Token expired
          localStorage.removeItem('crowdfaq_token');
          setToken(null);
          setUser(null);
        }
      } catch (error) {
        console.error('Failed to load user profile on boot:', error);
      } finally {
        setLoading(false);
      }
    }

    loadProfile();
  }, [token]);

  // Sync notifications
  const refreshNotifications = async () => {
    if (!token) return;
    try {
      const response = await fetch('/api/v1/notifications', {
        headers: {
          'Authorization': `Bearer ${token}`,
        }
      });
      if (response.ok) {
        const data = await response.json();
        setNotifications(data.notifications || []);
      }
    } catch (e) {
      console.error('Err fetching notifications:', e);
    }
  };

  useEffect(() => {
    if (user) {
      refreshNotifications();
      const interval = setInterval(refreshNotifications, 15000); // poll every 15s for simulated updates
      return () => clearInterval(interval);
    }
  }, [user]);

  const markNotificationsRead = async () => {
    if (!token) return;
    try {
      const response = await fetch('/api/v1/notifications/read', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
        }
      });
      if (response.ok) {
        setNotifications(prev => prev.map(n => ({ ...n, read: true })));
      }
    } catch (e) {
      console.error(e);
    }
  };

  const login = (newToken: string, newUser: User) => {
    localStorage.setItem('crowdfaq_token', newToken);
    setToken(newToken);
    setUser(newUser);
  };

  const logout = () => {
    localStorage.removeItem('crowdfaq_token');
    setToken(null);
    setUser(null);
    setNotifications([]);
  };

  const updateUser = (updatedUser: User) => {
    setUser(updatedUser);
  };

  const toggleTheme = () => {
    const nextTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(nextTheme);
    localStorage.setItem('crowdfaq_theme', nextTheme);
  };

  // Set HTML theme attribute class list
  useEffect(() => {
    const root = window.document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [theme]);

  const value = {
    token,
    user,
    loading,
    login,
    logout,
    updateUser,
    notifications,
    refreshNotifications,
    markNotificationsRead,
    theme,
    toggleTheme,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
