/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type UserRole = 'Student/Employee' | 'Expert' | 'Admin';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  points: number;
  badges: string[]; // e.g., 'Beginner', 'Top Contributor', 'Expert Helper', 'First Responder'
  biography: string;
  createdAt: string;
}

export interface Question {
  id: string;
  title: string;
  description: string;
  category: string; // e.g., 'Admissions', 'Placements', 'Scholarships', 'General'
  tags: string[];
  authorId: string;
  authorName: string;
  authorRole: UserRole;
  votesCount: number;
  votes: { [userId: string]: 'up' | 'down' }; // tracks user votes
  viewsCount: number;
  answersCount: number;
  isDuplicate: boolean;
  duplicateOfId?: string;
  duplicateOfTitle?: string;
  aiSummary?: string; // AI generated 2-line summary on top of responses
  createdAt: string;
}

export interface Comment {
  id: string;
  body: string;
  authorId: string;
  authorName: string;
  authorRole: UserRole;
  createdAt: string;
}

export interface Answer {
  id: string;
  questionId: string;
  body: string;
  authorId: string;
  authorName: string;
  authorRole: UserRole;
  votesCount: number;
  votes: { [userId: string]: 'up' | 'down' };
  isBest: boolean; // Set by question author
  isVerified: boolean; // Set by admin or expert (green checkmark)
  comments: Comment[];
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  createdAt: string;
}

export interface LeaderboardEntry {
  id: string;
  name: string;
  role: UserRole;
  points: number;
  badgesCount: number;
}
