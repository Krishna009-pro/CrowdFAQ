/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sparkles, Filter, Database, Users, HelpCircle, 
  ChevronRight, Calendar, ArrowRight, BookOpen, Clock, RefreshCcw 
} from 'lucide-react';

import Navbar from './components/Navbar';
import Sidebar from './components/Sidebar';
import AuthPage from './components/AuthPage';
import AskQuestionModal from './components/AskQuestionModal';
import QuestionCard from './components/QuestionCard';
import QuestionDetailView from './components/QuestionDetailView';
import LeaderboardPage from './components/LeaderboardPage';
import ProfilePage from './components/ProfilePage';
import AIChatbotWidget from './components/AIChatbotWidget';
import { Question } from './types';

function CrowdFaqAppContent() {
  const { user, token, loading } = useAuth();
  
  // Navigation Router states
  const [currentPage, setCurrentPage] = useState<string>('feed');
  const [selectedParams, setSelectedParams] = useState<any>(null);
  const [pageHistory, setPageHistory] = useState<string[]>([]);

  // Search and Filtering states
  const [searchVal, setSearchVal] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [questions, setQuestions] = useState<Question[]>([]);
  const [feedLoading, setFeedLoading] = useState<boolean>(true);

  // Modals state
  const [showAskModal, setShowAskModal] = useState<boolean>(false);

  const fetchQuestions = useCallback(async () => {
    setFeedLoading(true);
    try {
      const url = new URL('/api/v1/questions', window.location.origin);
      if (selectedCategory && selectedCategory !== 'All') {
        url.searchParams.append('category', selectedCategory);
      }
      if (searchVal) {
        url.searchParams.append('search', searchVal);
      }
      const res = await fetch(url.toString());
      if (res.ok) {
        const data = await res.json();
        setQuestions(data.questions || []);
      }
    } catch (e) {
      console.error('Failed to load questions list:', e);
    } finally {
      setFeedLoading(false);
    }
  }, [selectedCategory, searchVal]);

  useEffect(() => {
    fetchQuestions();
  }, [fetchQuestions]);

  const handleNavigate = (page: string, params: any = null) => {
    // Route guard check: If user tries to access profile when logged out, direct to auth Page
    if (!token && (page === 'profile')) {
      setCurrentPage('auth');
      return;
    }

    setPageHistory(prev => [...prev, currentPage]);
    setCurrentPage(page);
    setSelectedParams(params);
  };

  const handleOpenAskModal = () => {
    if (!token) {
      alert('Authentication is required to trigger ask operations.');
      setCurrentPage('auth');
      return;
    }
    setShowAskModal(true);
  };

  const handleQuestionCreated = (newQ: Question) => {
    setQuestions(prev => [newQ, ...prev]);
    // Redirect focus to the newly posted question
    handleNavigate('question-detail', { id: newQ.id });
  };

  if (loading) {
    return (
      <div className="flex h-screen w-screen flex-col items-center justify-center bg-white dark:bg-slate-950 font-mono text-xs text-slate-400">
        <span className="size-6 animate-spin rounded-full border-2 border-blue-600 border-t-transparent mb-3" />
        <span>Syncing CrowdFAQ portal parameters...</span>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50/40 text-slate-800 transition-colors dark:bg-slate-950 dark:text-slate-100 flex flex-col font-sans">
      
      {/* Dynamic Navbar */}
      <Navbar
        searchVal={searchVal}
        onSearchChange={setSearchVal}
        onNavigate={handleNavigate}
        onOpenAskModal={handleOpenAskModal}
      />

      <div className="mx-auto flex w-full max-w-7xl flex-1 pr-4 pl-4 sm:pr-6 sm:pl-6 lg:border-l lg:border-r border-slate-100 dark:border-slate-900">
        
        {/* Navigation Sidebar */}
        {currentPage !== 'auth' && (
          <Sidebar
            currentPage={currentPage}
            onOpenAskModal={handleOpenAskModal}
            onNavigate={handleNavigate}
          />
        )}

        {/* Primary Screen Viewports */}
        <main className={`flex-1 py-6 ${currentPage === 'auth' ? '' : 'md:pl-6'}`}>
          <AnimatePresence mode="wait">
            <motion.div
              key={currentPage + (selectedParams?.id || '')}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.15 }}
              className="h-full"
            >
              
              {/* Auth View */}
              {currentPage === 'auth' && (
                <AuthPage onNavigate={(p) => handleNavigate(p)} />
              )}

              {/* Feed Dashboard View */}
              {currentPage === 'feed' && (
                <div className="space-y-6 text-left">
                  
                  {/* Hero banner for welcome */}
                  {user && (
                    <div className="rounded-xl border border-dashed border-blue-200 bg-blue-50/10 p-5 dark:border-slate-800 dark:bg-slate-950/20 flex flex-col sm:flex-row items-center justify-between gap-4">
                      <div>
                        <h2 className="text-base font-bold text-slate-900 dark:text-white">
                          Welcome back, {user.name}! 🎓
                        </h2>
                        <p className="text-xs text-slate-500 dark:text-slate-400 mt-1 font-sans">
                          You currently have <span className="font-bold text-blue-600">{user.points} reputation score points</span> and earned <span className="font-bold text-blue-600">{user.badges.length} active digital badges</span>. Help community leads verify questions!
                        </p>
                      </div>
                      
                      <button
                        onClick={handleOpenAskModal}
                        className="rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white shadow-sm hover:bg-blue-700 cursor-pointer"
                      >
                        + Ask Place/Scholarship FAQ
                      </button>
                    </div>
                  )}

                  {/* 1. Category Filter Pill Row (Admissions, Placements, Scholarships, General, Academics) */}
                  <div className="flex flex-col gap-3">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none font-mono">
                      Academics Folder Filter
                    </span>
                    <div className="flex flex-wrap items-center gap-1.5 select-none animate-fade-in">
                      {['All', 'Admissions', 'Placements', 'Scholarships', 'General', 'Academics'].map((cat) => (
                        <button
                          key={cat}
                          onClick={() => setSelectedCategory(cat)}
                          className={`rounded-lg px-4 py-1.5 text-xs font-semibold border transition-all cursor-pointer ${
                            selectedCategory === cat
                              ? 'bg-blue-600 text-white border-blue-600 shadow-sm'
                              : 'bg-white text-slate-500 hover:text-slate-900 border-slate-200 hover:bg-slate-50 dark:bg-slate-950 dark:border-slate-800 dark:text-slate-400 dark:hover:text-slate-200'
                          }`}
                        >
                          {cat}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* 2. List header & counts */}
                  <div className="flex items-center justify-between border-b border-slate-100 pb-2 dark:border-slate-850">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest font-mono">
                      Outstanding community Q&As ({questions.length} elements)
                    </span>
                    <button
                      onClick={fetchQuestions}
                      title="Reload datasets"
                      className="p-1 rounded text-slate-400 hover:bg-slate-150 hover:text-slate-650"
                    >
                      <RefreshCcw className="h-3.5 w-3.5" />
                    </button>
                  </div>

                  {/* 3. Questions display board list */}
                  {feedLoading ? (
                    <div className="flex h-60 items-center justify-center font-mono text-xs text-slate-400">
                      <span className="size-4 animate-spin rounded-full border-2 border-blue-600 border-t-transparent mr-2" />
                      <span>Syncing central Q&A databases...</span>
                    </div>
                  ) : questions.length === 0 ? (
                    <div className="rounded-xl border border-dashed border-slate-300 py-16 text-center text-xs text-slate-400 dark:border-slate-850">
                      <Database className="mx-auto h-8 w-8 text-slate-350 dark:text-slate-650 mb-2" />
                      <span>No questions found matching this filter standard.</span>
                      <button
                        onClick={handleOpenAskModal}
                        className="mt-4 block mx-auto text-blue-600 font-bold hover:underline cursor-pointer"
                      >
                        Ask a new question now!
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 gap-4">
                      {questions.map((q) => (
                        <QuestionCard
                          key={q.id}
                          question={q}
                          onNavigate={handleNavigate}
                          onVoteSuccess={fetchQuestions}
                        />
                      ))}
                    </div>
                  )}

                </div>
              )}

              {/* Leaderboard Scoreboard view */}
              {currentPage === 'leaderboard' && (
                <LeaderboardPage />
              )}

              {/* Profile setup screen view */}
              {currentPage === 'profile' && (
                <ProfilePage />
              )}

              {/* Detailed Exploration view */}
              {currentPage === 'question-detail' && (
                <QuestionDetailView
                  questionId={selectedParams?.id}
                  onNavigate={handleNavigate}
                />
              )}

            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      {/* Floating AI Chatbot overlay drawer (Phase 2 MVP AI) */}
      <AIChatbotWidget />

      {/* Ask Question Popup Dialog Trigger modal */}
      <AnimatePresence>
        {showAskModal && (
          <AskQuestionModal
            onClose={() => setShowAskModal(false)}
            onQuestionCreated={handleQuestionCreated}
            onNavigate={handleNavigate}
          />
        )}
      </AnimatePresence>

    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <CrowdFaqAppContent />
    </AuthProvider>
  );
}
