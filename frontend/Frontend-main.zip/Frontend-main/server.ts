/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import crypto from 'crypto';
import { createServer as createViteServer } from 'vite';
import { db, hashPassword } from './src/db/store';
import { UserRole } from './src/types';
import {
  detectDuplicates,
  summarizeThreadAnswers,
  queryRAGChatbot,
  suggestTagsAndCategory
} from './src/services/ai';

const app = express();
const PORT = 3000;

app.use(express.json());

// JWT Utility with NO external dependencies
const TOKEN_SECRET = process.env.JWT_SECRET || 'crowdfaq-super-secret-key-2440';

export function generateToken(payload: { userId: string }): string {
  const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
  const exp = Date.now() + 7 * 24 * 3600 * 1000; // 7 days
  const data = Buffer.from(JSON.stringify({ ...payload, exp })).toString('base64url');
  const signature = crypto.createHmac('sha256', TOKEN_SECRET).update(`${header}.${data}`).digest('base64url');
  return `${header}.${data}.${signature}`;
}

export function verifyToken(token: string): { userId: string } | null {
  try {
    const [header, data, signature] = token.split('.');
    const expectedSignature = crypto.createHmac('sha256', TOKEN_SECRET).update(`${header}.${data}`).digest('base64url');
    if (signature !== expectedSignature) return null;
    const payload = JSON.parse(Buffer.from(data, 'base64url').toString('utf-8'));
    if (Date.now() > payload.exp) return null;
    return payload;
  } catch {
    return null;
  }
}

// Authentication Middleware
export interface AuthenticatedRequest extends Request {
  userId?: string;
  userRole?: UserRole;
  userName?: string;
}

function requireAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Authorization header is required (Bearer <token>)' });
  }

  const token = authHeader.split(' ')[1];
  const payload = verifyToken(token);
  if (!payload) {
    return res.status(401).json({ error: 'Invalid or expired token sessions. Please log in again.' });
  }

  const user = db.getUserById(payload.userId);
  if (!user) {
    return res.status(401).json({ error: 'User associated with this token does not exist.' });
  }

  req.userId = user.id;
  req.userRole = user.role;
  req.userName = user.name;
  next();
}

// ==========================================
// 1. HEALTH AND GENERAL ROUTES
// ==========================================
app.get('/api/v1/health', (req: Request, res: Response) => {
  res.json({ status: 'ok', time: new Date().toISOString(), platform: 'Google AI Studio Build' });
});

app.get('/api/health', (req: Request, res: Response) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// ==========================================
// 2. AUTHENTICATION / PROFILE ENDPOINTS
// ==========================================
app.post('/api/v1/auth/register', (req: Request, res: Response) => {
  const { email, name, password, role, biography } = req.body;

  if (!email || !name || !password) {
    return res.status(400).json({ error: 'Email, name, and password are required fields.' });
  }

  const existing = db.getUserByEmail(email);
  if (existing) {
    return res.status(400).json({ error: 'A user with this email email address already exists.' });
  }

  const validRoles: UserRole[] = ['Student/Employee', 'Expert', 'Admin'];
  const userRole = validRoles.includes(role) ? role : 'Student/Employee';

  const passHash = hashPassword(password);
  const user = db.createUser(email, name, userRole, biography, passHash);
  const token = generateToken({ userId: user.id });

  res.json({ token, user });
});

app.post('/api/v1/auth/login', (req: Request, res: Response) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required.' });
  }

  const user = db.getUserByEmail(email);
  if (!user || user.passwordHash !== hashPassword(password)) {
    return res.status(401).json({ error: 'Invalid email or password combination.' });
  }

  const token = generateToken({ userId: user.id });
  res.json({ token, user });
});

app.get('/api/v1/auth/profile', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const user = db.getUserById(req.userId!);
  res.json({ user });
});

app.put('/api/v1/auth/profile', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const { name, biography, role } = req.body;
  if (!name) {
    return res.status(400).json({ error: 'Name field cannot be left blank.' });
  }

  const updatedUser = db.updateUserProfile(req.userId!, name, biography, role);
  if (!updatedUser) {
    return res.status(404).json({ error: 'User account not found.' });
  }

  res.json({ user: updatedUser });
});

// ==========================================
// 3. CENTRAL FAQ & QUESTIONS ROUTES
// ==========================================
app.get('/api/v1/questions', (req: Request, res: Response) => {
  const { search, category, tag } = req.query;
  let list = db.getQuestions();

  if (category && category !== 'All') {
    list = list.filter(q => q.category.toLowerCase() === String(category).toLowerCase());
  }

  if (tag) {
    list = list.filter(q => q.tags.some(t => t.toLowerCase() === String(tag).toLowerCase()));
  }

  if (search) {
    const query = String(search).toLowerCase();
    list = list.filter(q => 
      q.title.toLowerCase().includes(query) || 
      q.description.toLowerCase().includes(query) ||
      q.tags.some(t => t.toLowerCase().includes(query))
    );
  }

  res.json({ questions: list });
});

app.post('/api/v1/questions', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const { title, description, category, tags } = req.body;

  if (!title || !description || !category) {
    return res.status(400).json({ error: 'Title, description, and category are required attributes.' });
  }

  const tagList = Array.isArray(tags) ? tags : [];

  const newQuestion = db.createQuestion(
    title,
    description,
    category,
    tagList,
    req.userId!,
    req.userName!,
    req.userRole!
  );

  res.json({ question: newQuestion });
});

app.get('/api/v1/questions/:id', (req: Request, res: Response) => {
  const q = db.getQuestionById(req.params.id);
  if (!q) {
    return res.status(404).json({ error: 'Question not found.' });
  }
  db.incrementQuestionViews(q.id);
  res.json({ question: q });
});

app.post('/api/v1/questions/:id/vote', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const { dir } = req.body;
  if (dir !== 'up' && dir !== 'down') {
    return res.status(400).json({ error: 'Vote direction must be "up" or "down".' });
  }

  const updated = db.voteQuestion(req.params.id, req.userId!, dir);
  if (!updated) {
    return res.status(404).json({ error: 'Question not found.' });
  }

  res.json({ question: updated });
});

app.post('/api/v1/questions/suggest-tags', requireAuth, async (req: Request, res: Response) => {
  const { title, description } = req.body;
  if (!title) {
    return res.status(400).json({ error: 'Title is required for tag suggestion.' });
  }

  const suggestions = await suggestTagsAndCategory(title, description || '');
  res.json(suggestions);
});

app.post('/api/v1/questions/duplicate-check', requireAuth, async (req: Request, res: Response) => {
  const { title, description } = req.body;
  if (!title) {
    return res.status(400).json({ error: 'Title is required for duplicate checking.' });
  }

  const results = await detectDuplicates(title, description || '');
  res.json(results);
});

// ==========================================
// 4. ANSWERS AND COMMENTS ENDPOINTS
// ==========================================
app.get('/api/v1/questions/:id/answers', (req: Request, res: Response) => {
  const answers = db.getAnswers(req.params.id);
  res.json({ answers });
});

app.post('/api/v1/questions/:id/answers', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const { body } = req.body;
  if (!body) {
    return res.status(400).json({ error: 'Answer body cannot be left empty.' });
  }

  const ans = db.createAnswer(req.params.id, body, req.userId!, req.userName!, req.userRole!);
  if (!ans) {
    return res.status(404).json({ error: 'Target question not found.' });
  }

  res.json({ answer: ans });
});

app.post('/api/v1/answers/:id/vote', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const { dir } = req.body;
  if (dir !== 'up' && dir !== 'down') {
    return res.status(400).json({ error: 'Direction must be "up" or "down".' });
  }

  const ans = db.voteAnswer(req.params.id, req.userId!, dir);
  if (!ans) {
    return res.status(404).json({ error: 'Answer not found.' });
  }

  res.json({ answer: ans });
});

app.post('/api/v1/answers/:id/best', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const ans = db.getAnswerById(req.params.id);
  if (!ans) {
    return res.status(404).json({ error: 'Answer not found.' });
  }

  const question = db.getQuestionById(ans.questionId);
  if (!question) {
    return res.status(404).json({ error: 'Question associated with answer not found.' });
  }

  // Best checkmark ONLY visible/controlled by user who wrote original question (OCR page 26 Dev 6)
  if (question.authorId !== req.userId) {
    return res.status(403).json({ error: 'Only the author of the question can choose the Best Answer mark.' });
  }

  const updated = db.acceptAnswerAsBest(ans.id);
  res.json({ answer: updated });
});

app.post('/api/v1/answers/:id/verify', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  // Verified Answer green shield badge visible only if logged-in user is Expert or Admin (OCR page 26 Dev 6)
  if (req.userRole !== 'Admin' && req.userRole !== 'Expert') {
    return res.status(403).json({ error: 'Only teachers, volunteer leads, or admins can officially verify answers.' });
  }

  const updated = db.verifyAnswer(req.params.id, req.userId!, req.userName!);
  if (!updated) {
    return res.status(404).json({ error: 'Answer not found.' });
  }

  res.json({ answer: updated });
});

app.post('/api/v1/answers/:id/comments', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const { body } = req.body;
  if (!body) {
    return res.status(400).json({ error: 'Comment text is required.' });
  }

  const comment = db.addComment(req.params.id, body, req.userId!, req.userName!, req.userRole!);
  if (!comment) {
    return res.status(404).json({ error: 'Answer not found to attach comment.' });
  }

  res.json({ comment });
});

app.post('/api/v1/questions/:id/summarize', requireAuth, async (req: Request, res: Response) => {
  const summary = await summarizeThreadAnswers(req.params.id);
  if (summary) {
    db.updateQuestionAiSummary(req.params.id, summary);
  }
  res.json({ summary });
});

// ==========================================
// 5. LEADERBOARDS & NOTIFICATIONS & BOT
// ==========================================
app.get('/api/v1/leaderboard', (req: Request, res: Response) => {
  const users = db.getUsers();
  // Sort by points descending
  const leaderboard = users
    .map(u => ({
      id: u.id,
      name: u.name,
      role: u.role,
      points: u.points,
      badgesCount: u.badges.length,
      badges: u.badges,
      biography: u.biography,
    }))
    .sort((a,b) => b.points - a.points);

  res.json({ leaderboard });
});

app.get('/api/v1/notifications', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  const list = db.getNotifications(req.userId!);
  res.json({ notifications: list });
});

app.post('/api/v1/notifications/read', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  db.markNotificationsRead(req.userId!);
  res.json({ success: true });
});

// AI Chatbot RAG query
app.post('/api/v1/chatbot/query', requireAuth, async (req: AuthenticatedRequest, res: Response) => {
  const { message, sessionId } = req.body;
  if (!message) {
    return res.status(400).json({ error: 'Message payload is required.' });
  }

  const activeSessionId = sessionId || 'session_default';
  const reply = await queryRAGChatbot(message, activeSessionId);
  res.json({ reply, sessionId: activeSessionId });
});

// ==========================================
// VITE AND STATIC SERVING PIPELINE
// ==========================================
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    // Mount Vite development middlewares
    app.use(vite.middlewares);
  } else {
    // Serve static frontend assets in production mode from /dist
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 CrowdFAQ Back-Backend & Front-Client integrated server live on port ${PORT}`);
  });
}

startServer();
